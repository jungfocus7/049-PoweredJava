﻿namespace PRPI_QueryBinder
{
    partial class QueryBinderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QueryBinderForm));
            this.m_grb1 = new System.Windows.Forms.GroupBox();
            this.m_txbComment = new System.Windows.Forms.TextBox();
            this.m_btnFunc = new System.Windows.Forms.Button();
            this.m_txbParams = new System.Windows.Forms.TextBox();
            this.m_btn11 = new System.Windows.Forms.Button();
            this.m_txbQuery = new System.Windows.Forms.TextBox();
            this.m_grb2 = new System.Windows.Forms.GroupBox();
            this.m_btn21 = new System.Windows.Forms.Button();
            this.m_txb21 = new System.Windows.Forms.TextBox();
            this.m_grb3 = new System.Windows.Forms.GroupBox();
            this.m_btn31 = new System.Windows.Forms.Button();
            this.m_txb31 = new System.Windows.Forms.TextBox();
            this.m_grb1.SuspendLayout();
            this.m_grb2.SuspendLayout();
            this.m_grb3.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_grb1
            // 
            this.m_grb1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_grb1.Controls.Add(this.m_txbComment);
            this.m_grb1.Controls.Add(this.m_btnFunc);
            this.m_grb1.Controls.Add(this.m_txbParams);
            this.m_grb1.Controls.Add(this.m_btn11);
            this.m_grb1.Controls.Add(this.m_txbQuery);
            this.m_grb1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m_grb1.Location = new System.Drawing.Point(9, 459);
            this.m_grb1.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.m_grb1.Name = "m_grb1";
            this.m_grb1.Padding = new System.Windows.Forms.Padding(0);
            this.m_grb1.Size = new System.Drawing.Size(782, 407);
            this.m_grb1.TabIndex = 5;
            this.m_grb1.TabStop = false;
            this.m_grb1.Text = "   ▩ 쿼리, 파라미터 입력   ";
            // 
            // m_txbComment
            // 
            this.m_txbComment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_txbComment.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_txbComment.HideSelection = false;
            this.m_txbComment.Location = new System.Drawing.Point(3, 20);
            this.m_txbComment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_txbComment.Multiline = true;
            this.m_txbComment.Name = "m_txbComment";
            this.m_txbComment.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_txbComment.Size = new System.Drawing.Size(776, 90);
            this.m_txbComment.TabIndex = 0;
            this.m_txbComment.WordWrap = false;
            // 
            // m_btnFunc
            // 
            this.m_btnFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btnFunc.BackColor = System.Drawing.Color.Plum;
            this.m_btnFunc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btnFunc.Location = new System.Drawing.Point(649, 333);
            this.m_btnFunc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btnFunc.Name = "m_btnFunc";
            this.m_btnFunc.Size = new System.Drawing.Size(130, 68);
            this.m_btnFunc.TabIndex = 4;
            this.m_btnFunc.Text = "▶▶ 기능 메뉴";
            this.m_btnFunc.UseVisualStyleBackColor = false;
            // 
            // m_txbParams
            // 
            this.m_txbParams.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_txbParams.Font = new System.Drawing.Font("나눔고딕", 8.999999F);
            this.m_txbParams.HideSelection = false;
            this.m_txbParams.Location = new System.Drawing.Point(3, 291);
            this.m_txbParams.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_txbParams.Multiline = true;
            this.m_txbParams.Name = "m_txbParams";
            this.m_txbParams.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_txbParams.Size = new System.Drawing.Size(640, 110);
            this.m_txbParams.TabIndex = 2;
            this.m_txbParams.WordWrap = false;
            // 
            // m_btn11
            // 
            this.m_btn11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btn11.BackColor = System.Drawing.Color.LightSteelBlue;
            this.m_btn11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btn11.Location = new System.Drawing.Point(649, 291);
            this.m_btn11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btn11.Name = "m_btn11";
            this.m_btn11.Size = new System.Drawing.Size(130, 34);
            this.m_btn11.TabIndex = 3;
            this.m_btn11.Text = "▲▲ 쿼리 완성";
            this.m_btn11.UseVisualStyleBackColor = false;
            // 
            // m_txbQuery
            // 
            this.m_txbQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_txbQuery.Font = new System.Drawing.Font("나눔고딕", 8.999999F);
            this.m_txbQuery.HideSelection = false;
            this.m_txbQuery.Location = new System.Drawing.Point(3, 118);
            this.m_txbQuery.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_txbQuery.Multiline = true;
            this.m_txbQuery.Name = "m_txbQuery";
            this.m_txbQuery.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_txbQuery.Size = new System.Drawing.Size(776, 165);
            this.m_txbQuery.TabIndex = 1;
            this.m_txbQuery.WordWrap = false;
            // 
            // m_grb2
            // 
            this.m_grb2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_grb2.Controls.Add(this.m_btn21);
            this.m_grb2.Controls.Add(this.m_txb21);
            this.m_grb2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold);
            this.m_grb2.Location = new System.Drawing.Point(9, 254);
            this.m_grb2.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.m_grb2.Name = "m_grb2";
            this.m_grb2.Size = new System.Drawing.Size(782, 200);
            this.m_grb2.TabIndex = 4;
            this.m_grb2.TabStop = false;
            this.m_grb2.Text = "   ▩ 완성 쿼리 출력   ";
            // 
            // m_btn21
            // 
            this.m_btn21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btn21.BackColor = System.Drawing.Color.LightSteelBlue;
            this.m_btn21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btn21.Location = new System.Drawing.Point(646, 158);
            this.m_btn21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btn21.Name = "m_btn21";
            this.m_btn21.Size = new System.Drawing.Size(130, 34);
            this.m_btn21.TabIndex = 1;
            this.m_btn21.Text = "▲▲ 쿼리 실행";
            this.m_btn21.UseVisualStyleBackColor = false;
            // 
            // m_txb21
            // 
            this.m_txb21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_txb21.Font = new System.Drawing.Font("나눔고딕", 8.999999F);
            this.m_txb21.HideSelection = false;
            this.m_txb21.Location = new System.Drawing.Point(6, 23);
            this.m_txb21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_txb21.Multiline = true;
            this.m_txb21.Name = "m_txb21";
            this.m_txb21.ReadOnly = true;
            this.m_txb21.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_txb21.Size = new System.Drawing.Size(770, 124);
            this.m_txb21.TabIndex = 0;
            this.m_txb21.WordWrap = false;
            // 
            // m_grb3
            // 
            this.m_grb3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_grb3.Controls.Add(this.m_btn31);
            this.m_grb3.Controls.Add(this.m_txb31);
            this.m_grb3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m_grb3.Location = new System.Drawing.Point(9, 9);
            this.m_grb3.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.m_grb3.Name = "m_grb3";
            this.m_grb3.Size = new System.Drawing.Size(782, 240);
            this.m_grb3.TabIndex = 3;
            this.m_grb3.TabStop = false;
            this.m_grb3.Text = "   ▩ 쿼리 결과 출력   ";
            // 
            // m_btn31
            // 
            this.m_btn31.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btn31.BackColor = System.Drawing.Color.LightSteelBlue;
            this.m_btn31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btn31.Location = new System.Drawing.Point(626, 199);
            this.m_btn31.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btn31.Name = "m_btn31";
            this.m_btn31.Size = new System.Drawing.Size(150, 34);
            this.m_btn31.TabIndex = 1;
            this.m_btn31.Text = "▲▲ 클립보드 복사";
            this.m_btn31.UseVisualStyleBackColor = false;
            // 
            // m_txb31
            // 
            this.m_txb31.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_txb31.Font = new System.Drawing.Font("나눔고딕", 8.999999F);
            this.m_txb31.HideSelection = false;
            this.m_txb31.Location = new System.Drawing.Point(6, 23);
            this.m_txb31.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_txb31.Multiline = true;
            this.m_txb31.Name = "m_txb31";
            this.m_txb31.ReadOnly = true;
            this.m_txb31.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_txb31.Size = new System.Drawing.Size(770, 168);
            this.m_txb31.TabIndex = 0;
            this.m_txb31.WordWrap = false;
            // 
            // QueryBinderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 875);
            this.Controls.Add(this.m_grb1);
            this.Controls.Add(this.m_grb2);
            this.Controls.Add(this.m_grb3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(100, 40);
            this.Name = "QueryBinderForm";
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.m_grb1.ResumeLayout(false);
            this.m_grb1.PerformLayout();
            this.m_grb2.ResumeLayout(false);
            this.m_grb2.PerformLayout();
            this.m_grb3.ResumeLayout(false);
            this.m_grb3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox m_grb1;
        private System.Windows.Forms.TextBox m_txbComment;
        private System.Windows.Forms.Button m_btnFunc;
        private System.Windows.Forms.TextBox m_txbParams;
        private System.Windows.Forms.Button m_btn11;
        private System.Windows.Forms.TextBox m_txbQuery;
        private System.Windows.Forms.GroupBox m_grb2;
        private System.Windows.Forms.Button m_btn21;
        private System.Windows.Forms.TextBox m_txb21;
        private System.Windows.Forms.GroupBox m_grb3;
        private System.Windows.Forms.Button m_btn31;
        private System.Windows.Forms.TextBox m_txb31;
    }
}