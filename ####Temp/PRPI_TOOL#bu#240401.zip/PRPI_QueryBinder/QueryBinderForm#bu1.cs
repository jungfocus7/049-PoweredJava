﻿using PRPI_QueryBinder.CustomControls;
using PRPI_QueryBinder.DataProviders;
using RootAppCommon;
using RootAppCommon.Controls;
using RootAppCommon.DataExtentions;
using RootAppCommon.Managers;
using System;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;




namespace PRPI_QueryBinder
{
    public sealed partial class QueryBinderForm : Form
    {
        #region  [ 00) 객체 초기화 영역 ]
        /// <summary>
        /// 생성자
        /// </summary>
        public QueryBinderForm()
        {
            InitializeComponent();
        }


        /// <summary>
        /// Load 이벤트
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            this.AlignBottomRight(40, 40);
            this.ResizeRenderingPass();
            MinimumSize = Size;
            Text = "01) PRPI_QueryBinder";

            prQueryDataLoad();
            prControlsInitialize();            
        }


        /// <summary>
        /// OnClosing
        /// </summary>
        /// <param name="e"></param>
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);

            Application.Exit();
            //e.Cancel = true;
            //Hide();
        }


        ///// <summary>
        ///// OnClosed
        ///// </summary>
        ///// <param name="e"></param>
        //protected override void OnClosed(EventArgs e)
        //{
        //    base.OnClosed(e);

        //    Application.Exit();
        //}



        /// <summary>
        /// 컨트롤들 초기화
        /// </summary>
        private void prControlsInitialize()
        {
            prGroup01_InitOnce();
            prGroup02_InitOnce();
            prGroup03_InitOnce();

            AllowDrop = true;
        }


        /// <summary>
        /// 파일 드래그 엔터
        /// </summary>
        /// <param name="e"></param>
        protected override void OnDragEnter(DragEventArgs e)
        {
            base.OnDragEnter(e);

            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Copy;
        }


        /// <summary>
        /// 파일 드래그 드롭
        /// </summary>
        /// <param name="e"></param>
        protected override void OnDragDrop(DragEventArgs e)
        {
            base.OnDragDrop(e);

            IDataObject tdo = e.Data;
            if (tdo.GetData(DataFormats.FileDrop) is string[] fpa)
            {
                if (fpa.Length == 1)
                {
                    string xfp = fpa[0];
                    if (Path.GetExtension(xfp).ToLower() == ".xml")
                        prQueryDataLoad(xfp);
                }
            }
        }
        #endregion




        #region [ 91) 공통 함수들 모음 ]
        /// <summary>
        /// (공통) 클립보드 붙여넣기
        /// </summary>
        /// <param name="txb"></param>
        private static void prCommonClipboardPaste(TextBox txb)
        {
            if (Clipboard.ContainsText())
            {
                string txt = Clipboard.GetText();
                if (string.IsNullOrWhiteSpace(txt) == false)
                    txb.Text = txt;
            }
        }


        /// <summary>
        /// (공통) 클립보드 복사하기
        /// </summary>
        /// <param name="txb"></param>
        private static void prCommonClipboardCopy(TextBox txb)
        {
            string txt = txb.Text;
            if (string.IsNullOrWhiteSpace(txt) == false)
                Clipboard.SetText(txt);
        }
        #endregion




        #region [ 92) 데이터 열기/저장 ]
        /// <summary>
        /// QueryData Load
        /// </summary>
        /// <param name="xfp"></param>
        private void prQueryDataLoad(string xfp = null)
        {
            if (QueryDataProvider.Load(xfp))
            {
                prClearAll();
                m_txbComment.Text = QueryDataProvider.Comment;
                m_txbQuery.Text = QueryDataProvider.Query;
                m_txbParams.Text = QueryDataProvider.Parameters;
                m_tsmi41?.SetChecked(QueryDataProvider.BindType);
            }
        }


        /// <summary>
        /// QueryData LoadAs
        /// </summary>
        private void prQueryDataLoadAs()
        {
            if (QueryDataProvider.LoadAs())
            {
                prClearAll();
                m_txbComment.Text = QueryDataProvider.Comment;
                m_txbQuery.Text = QueryDataProvider.Query;
                m_txbParams.Text = QueryDataProvider.Parameters;
                m_tsmi41?.SetChecked(QueryDataProvider.BindType);
            }
        }


        /// <summary>
        /// QueryData Save
        /// </summary>
        /// <param name="xfp"></param>
        private void prQueryDataSave(string xfp = null)
        {
            string comment = m_txbComment.Text;
            string query = m_txbQuery.Text;
            string parameters = m_txbParams.Text;
            QueryDataProvider.UpdateItems(comment, query, parameters);
            QueryDataProvider.Save(xfp);
        }


        /// <summary>
        /// QueryData SaveAs
        /// </summary>
        private void prQueryDataSaveAs()
        {
            string comment = m_txbComment.Text;
            string query = m_txbQuery.Text;
            string parameters = m_txbParams.Text;
            QueryDataProvider.UpdateItems(comment, query, parameters);
            QueryDataProvider.SaveAs();
        }


        /// <summary>
        /// QueryData QuickSave
        /// </summary>
        private void prQueryDataQuickSave()
        {
            string comment = m_txbComment.Text;
            string query = m_txbQuery.Text;
            string parameters = m_txbParams.Text;
            QueryDataProvider.UpdateItems(comment, query, parameters);
            string xfp = QueryDataProvider.GetQuickFilePath();            
            QueryDataProvider.Save(xfp);
        }


        /// <summary>
        /// 쿼리 완성하기
        /// </summary>
        /// <param name="bCopy"></param>
        private void prCompleteQuery(bool bCopy = false)
        {
            string query = m_txbQuery.Text;
            string parameters = m_txbParams.Text;
            string outstr = null;

            // 쿼리부분 없으면 리턴
            if (string.IsNullOrWhiteSpace(query))
            {
                AppCommon.Alert("입력 쿼리 없음");
                return;
            }

            // 파리미터 없으면 쿼리만 리턴
            if (string.IsNullOrWhiteSpace(parameters))
            {
                outstr = query;
            }
            else
            {
                //string[] tpa = parameters.Split(
                //    new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                string[] tpa = parameters.Split(
                    new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

                // Bt_QuestionMark 사용
                if (QueryDataProvider.BindType == QueryDataProvider.Bt_QuestionMark)
                {
                    int i = 0;
                    outstr = Regex.Replace(query, "\\?",
                        delegate (Match mt)
                        {
                            try
                            {
                                string tx = tpa[i++].Trim();
                                return tx;
                            }
                            catch
                            {
                                return string.Empty;
                            }
                        }, RegexOptions.None);
                }

                // Bt_StringFormat 사용
                else if (QueryDataProvider.BindType == QueryDataProvider.Bt_StringFormat)
                {
                    try
                    {
                        outstr = string.Format(query, tpa);
                    }
                    catch
                    {
                        outstr = null;
                    }
                }
            }


            if (string.IsNullOrWhiteSpace(outstr) == false)
            {
                m_txb21.Text = outstr;
                if (bCopy)
                    Clipboard.SetText(outstr);
            }
        }


        /// <summary>
        /// 쿼리 실행하기
        /// </summary>
        /// <param name="bCopy"></param>
        private void prRunQuery(bool bCopy = false)
        {
            string tqs = m_txb21.Text;
            if (string.IsNullOrWhiteSpace(tqs))
                AppCommon.Alert(this, "완성 쿼리 없음");
            else
            {
                DataTable tdt = DataManager.SelectData(tqs);
                if (tdt.IsEmpty())
                    AppCommon.Alert(this, "데이터가 없음");
                else
                    prOutputText(tdt, bCopy);
            }
        }


        /// <summary>
        /// DataTable > 문자열
        /// </summary>
        /// <param name="tdt">DataTable</param>
        /// <param name="bCopy"></param>
        private void prOutputText(DataTable tdt, bool bCopy = false)
        {
            DataColumnCollection dcc = tdt.Columns;
            DataRowCollection drc = tdt.Rows;
            if (dcc.Count == 0) return;
            if (drc.Count == 0) return;

            StringBuilder msb = new StringBuilder();
            bool bFirst = true;
            foreach (DataColumn dc in dcc)
            {
                if (bFirst)
                {
                    msb.Append(dc.ColumnName);
                    bFirst = false;
                }
                else
                {
                    msb.Append($"	{dc.ColumnName}");
                }
            }

            foreach (DataRow dr in drc)
            {
                msb.AppendLine();
                bFirst = true;

                foreach (object to in dr.ItemArray)
                {
                    if (bFirst)
                    {
                        msb.Append(to.ToString());
                        bFirst = false;
                    }
                    else
                    {
                        msb.Append($"	{to.ToString()}");
                    }
                }
            }

            if (msb.Length > 0)
            {
                string tos = msb.ToString();
                m_txb31.Text = tos;
                if (bCopy)
                    Clipboard.SetText(tos);
            }

            tdt.Release();
        }


        /// <summary>
        /// 모든내용 비우기
        /// </summary>
        private void prClearAll(bool bu = false)
        {
            if (bu) QueryDataProvider.Unload();
            m_txbComment.Clear();
            m_txbQuery.Clear();
            m_txbParams.Clear();
            m_txb21.Clear();
            m_txb31.Clear();
        }
        #endregion




        #region [ 01) 쿼리, 파라미터 입력 ]
        private CmsEx m_cms11;
        private Tsmi41Group m_tsmi41;
        private CmsEx m_cmsFunc;        


        /// <summary>
        /// Group01 InitOnce
        /// </summary>
        private void prGroup01_InitOnce()
        {
            ToolStripItem[] tsia;

            m_cms11 = new CmsEx(this);
            m_tsmi41 = new Tsmi41Group("3) 바인드 타입: ",
                MenuItemNames.Tsn_3,
                new Tsmi41[]
                {
                    new Tsmi41(QueryDataProvider.Bt_QuestionMark, "z) ", MenuItemNames.Tsn_z),
                    new Tsmi41(QueryDataProvider.Bt_StringFormat, "x) ", MenuItemNames.Tsn_x)
                },
                pr_Tsmi41Group_Callback);
            m_tsmi41.SetChecked(QueryDataProvider.BindType);
            tsia = new ToolStripItem[]
            {
                new Tsmi31("1) 쿼리 완성하기", MenuItemNames.Tsn_1, pr_cms11__Click),
                new Tsmi31("2) 쿼리 완성하기후 클립보드", MenuItemNames.Tsn_2, pr_cms11__Click),
                m_tsmi41,
                new ToolStripSeparator(),
                new Tsmi31("a) 코멘트 클립보드 붙여넣기", MenuItemNames.Tsn_a, pr_cms11__Click),
                new Tsmi31("b) 코멘트 클립보드 복사하기", MenuItemNames.Tsn_b, pr_cms11__Click),
                new Tsmi31("c) 코멘트 내용 비우기", MenuItemNames.Tsn_c, pr_cms11__Click),
                new ToolStripSeparator(),
                new Tsmi31("d) 쿼리 클립보드 붙여넣기", MenuItemNames.Tsn_d, pr_cms11__Click),
                new Tsmi31("e) 쿼리 클립보드 복사하기", MenuItemNames.Tsn_e, pr_cms11__Click),
                new Tsmi31("f) 쿼리 내용 비우기", MenuItemNames.Tsn_f, pr_cms11__Click),
                new ToolStripSeparator(),
                new Tsmi31("g) 파라미터 클립보드 붙여넣기", MenuItemNames.Tsn_g, pr_cms11__Click),
                new Tsmi31("h) 파라미터 클립보드 복사하기", MenuItemNames.Tsn_h, pr_cms11__Click),
                new Tsmi31("i) 파라미터 내용 비우기", MenuItemNames.Tsn_i, pr_cms11__Click),
            };
            m_cms11.Items.AddRange(tsia);
            m_btn11.ContextMenuStrip = m_cms11;
            m_btn11.Click += pr_btn11__Click;

            m_cmsFunc = new CmsEx(this);
            tsia = new ToolStripItem[]
            {
                new Tsmi31("1) Default로 새로고침", MenuItemNames.Tsn_1, pr_cmsFunc__Click),
                new Tsmi31("2) Default로 저장하기", MenuItemNames.Tsn_2, pr_cmsFunc__Click),
                new ToolStripSeparator(),
                new Tsmi31("3) 다른이름 불러오기", MenuItemNames.Tsn_3, pr_cmsFunc__Click),
                new Tsmi31("4) 다른이름 저장하기", MenuItemNames.Tsn_4, pr_cmsFunc__Click),
                new Tsmi31("5) 빠른 저장하기", MenuItemNames.Tsn_5, pr_cmsFunc__Click),
                new ToolStripSeparator(),
                new Tsmi31("6) 저장폴더 열기", MenuItemNames.Tsn_6, pr_cmsFunc__Click),
                new ToolStripSeparator(),
                new Tsmi31("7) 모든 내용 비우기", MenuItemNames.Tsn_7, pr_cmsFunc__Click)
            };
            m_cmsFunc.Items.AddRange(tsia);
            m_btnFunc.ContextMenuStrip = m_cmsFunc;
            m_btnFunc.Click += pr_btnFunc__Click;
        }


        /// <summary>
        /// ???
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pr_cms11__Click(object sender, EventArgs e)
        {
            if (sender is ToolStripItem tsi)
            {
                switch (tsi.Name)
                {
                    case MenuItemNames.Tsn_1: // 1) 쿼리 완성하기
                    {
                        prCompleteQuery();
                        break;
                    }

                    case MenuItemNames.Tsn_2: // 2) 쿼리 완성하기후 클립보드
                    {
                        prCompleteQuery(true);
                        break;
                    }

                    //case MenuItemNames.Tsn_3: // 3) 바인드 타입
                    //{
                    //    break;
                    //}

                    //case MenuItemNames.Tsn_z: // 3) 바인드 타입 > z) QueryItem.BT_QuestionMark
                    //{
                    //    string btp = QueryDataProvider.BindType;
                    //    if (btp != QueryDataProvider.Bt_QuestionMark)
                    //    {
                    //        btp = QueryDataProvider.Bt_QuestionMark;
                    //        m_cms11.Items[2].Text = $"3) 바인드 타입: {btp}";
                    //        QueryDataProvider.BindType = btp;
                    //    }
                    //    break;
                    //}

                    //case MenuItemNames.Tsn_x: // 3) 바인드 타입 > x) QueryItem.BT_StringFormat
                    //{
                    //    string btp = QueryDataProvider.BindType;
                    //    if (btp != QueryDataProvider.Bt_StringFormat)
                    //    {
                    //        btp = QueryDataProvider.Bt_StringFormat;
                    //        m_cms11.Items[2].Text = $"3) 바인드 타입: {btp}";
                    //        QueryDataProvider.BindType = btp;
                    //    }
                    //    break;
                    //}

                    case MenuItemNames.Tsn_a: // a) 코멘트 클립보드 붙여넣기
                    {
                        prCommonClipboardPaste(m_txbComment);
                        break;
                    }

                    case MenuItemNames.Tsn_b: // b) 코멘트 클립보드 복사하기
                    {
                        prCommonClipboardCopy(m_txbComment);
                        break;
                    }

                    case MenuItemNames.Tsn_c: // c) 코멘트 내용 비우기
                    {
                        m_txbComment.Clear();
                        break;
                    }

                    case MenuItemNames.Tsn_d: // d) 쿼리 클립보드 붙여넣기
                    {
                        prCommonClipboardPaste(m_txbQuery);
                        break;
                    }

                    case MenuItemNames.Tsn_e: // e) 쿼리 클립보드 복사하기
                    {
                        prCommonClipboardCopy(m_txbQuery);
                        break;
                    }

                    case MenuItemNames.Tsn_f: // f) 쿼리 내용 비우기
                    {
                        m_txbQuery.Clear();
                        break;
                    }

                    case MenuItemNames.Tsn_g: // g) 파라미터 클립보드 붙여넣기
                    {
                        prCommonClipboardPaste(m_txbParams);
                        break;
                    }

                    case MenuItemNames.Tsn_h: // h) 파라미터 클립보드 복사하기
                    {
                        prCommonClipboardCopy(m_txbParams);
                        break;
                    }

                    case MenuItemNames.Tsn_i: // i) 파라미터 내용 비우기
                    {
                        m_txbParams.Clear();
                        break;
                    }

                    default: break;
                }
            }
        }


        /// <summary>
        /// 쿼리 완성 버튼 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pr_btn11__Click(object sender, EventArgs e)
        {
            prCompleteQuery();
        }


        /// <summary>
        /// Tsmi41Group Callback
        /// </summary>
        /// <param name="tp"></param>
        /// <param name="gp"></param>
        /// <param name="ap"></param>
        private void pr_Tsmi41Group_Callback(string tp, Tsmi41 ap)
        {
            if (tp == Tsmi41Group.Cbt_ItemSelected)
            {
                QueryDataProvider.BindType = ap.Rtg;
            }
        }


        /// <summary>
        /// ???
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pr_cmsFunc__Click(object sender, EventArgs e)
        {
            if (sender is ToolStripItem tsi)
            {
                switch (tsi.Name)
                {
                    case MenuItemNames.Tsn_1: // 1) Default로 새로고침
                    {
                        prQueryDataLoad();
                        break;
                    }

                    case MenuItemNames.Tsn_2: // 2) Default로 저장하기
                    {
                        prQueryDataSave();
                        break;
                    }

                    case MenuItemNames.Tsn_3: // 3) 다른이름 불러오기
                    {
                        prQueryDataLoadAs();
                        break;
                    }

                    case MenuItemNames.Tsn_4: // 4) 다른이름 저장하기
                    {
                        prQueryDataSaveAs();
                        break;
                    }

                    case MenuItemNames.Tsn_5: // 5) 빠른 저장하기
                    {
                        prQueryDataQuickSave();
                        break;
                    }

                    case MenuItemNames.Tsn_6: // 6) 저장폴더 열기
                    {
                        QueryDataProvider.OpenFolder();
                        break;
                    }

                    case MenuItemNames.Tsn_7: // 7) 모든 내용 비우기
                    {
                        prClearAll(true);
                        break;
                    }

                    default: break;
                }
            }
        }


        /// <summary>
        /// 기능 메뉴 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pr_btnFunc__Click(object sender, EventArgs e)
        {
            AppCommon.Alert("오른쪽 버튼 클릭");
        }
        #endregion




        #region [ 02) 완성 쿼리 출력 ]
        private CmsEx m_cms21;


        /// <summary>
        /// Group02 InitOnce
        /// </summary>
        private void prGroup02_InitOnce()
        {
            m_cms21 = new CmsEx(this);
            ToolStripItem[] tsia = new ToolStripItem[]
            {
                new Tsmi31("1) 쿼리 실행하기", MenuItemNames.Tsn_1, pr_cms21__Click),
                new Tsmi31("2) 쿼리 실행후 클립보드", MenuItemNames.Tsn_2, pr_cms21__Click),
                new ToolStripSeparator(),
                new Tsmi31("5) 결과 클립보드 복사하기", MenuItemNames.Tsn_5, pr_cms21__Click),
                new Tsmi31("6) 결과 내용 비우기", MenuItemNames.Tsn_6, pr_cms21__Click)
            };
            m_cms21.Items.AddRange(tsia);
            m_btn21.ContextMenuStrip = m_cms21;
            m_btn21.Click += pr_btn21__Click;
        }


        /// <summary>
        /// ???
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pr_cms21__Click(object sender, EventArgs e)
        {
            if (sender is ToolStripItem tsi)
            {
                switch (tsi.Name)
                {
                    case MenuItemNames.Tsn_1: // 1) 쿼리 실행하기
                    {
                        prRunQuery();
                        break;
                    }

                    case MenuItemNames.Tsn_2: // 2) 쿼리 실행후 클립보드
                    {
                        prRunQuery(true);
                        break;
                    }

                    case MenuItemNames.Tsn_5: // 5) 결과 클립보드 복사하기
                    {
                        prCommonClipboardCopy(m_txb21);
                        break;
                    }

                    case MenuItemNames.Tsn_6: // 6) 결과 내용 비우기
                    {
                        m_txb21.Clear();
                        break;
                    }

                    default: break;
                }
            }
        }


        /// <summary>
        /// 쿼리 실행 버튼
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pr_btn21__Click(object sender, EventArgs e)
        {
            prRunQuery();
        }
        #endregion




        #region [ 03) 쿼리 결과 출력 ]
        private CmsEx m_cms31;


        /// <summary>
        /// Group03 InitOnce
        /// </summary>
        private void prGroup03_InitOnce()
        {
            m_grb1.Text = $"   ▩ 쿼리, 파라미터 입력 (구분자 |(Vertical Bar) 사용함)   ";

            m_cms31 = new CmsEx(this);
            ToolStripItem[] tsia = new ToolStripItem[]
            {
                new Tsmi31("5) 결과 클립보드 복사하기", MenuItemNames.Tsn_5, pr_cms31__Click),
                new Tsmi31("6) 결과 내용 비우기", MenuItemNames.Tsn_6, pr_cms31__Click),
                new ToolStripSeparator(),
                new Tsmi31("7) 결과 CSV로 빠른 저장하기", MenuItemNames.Tsn_7, pr_cms31__Click),
                new Tsmi31("8) 결과 CSV로 다른이름 저장하기", MenuItemNames.Tsn_8, pr_cms31__Click)
            };
            m_cms31.Items.AddRange(tsia);
            m_btn31.ContextMenuStrip = m_cms31;
            m_btn31.Click += pr_btn31__Click;
        }


        /// <summary>
        /// ???
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pr_cms31__Click(object sender, EventArgs e)
        {
            if (sender is ToolStripItem tsi)
            {
                switch (tsi.Name)
                {
                    case MenuItemNames.Tsn_5: // 5) 결과 클립보드 복사하기
                    {
                        prCommonClipboardCopy(m_txb31);
                        break;
                    }

                    case MenuItemNames.Tsn_6: // 6) 결과 내용 비우기
                    {
                        m_txb31.Clear();
                        break;
                    }

                    case MenuItemNames.Tsn_7: // 7) 결과 CSV로 빠른 저장하기
                    {
                        //
                        break;
                    }

                    case MenuItemNames.Tsn_8: // 8) 결과 CSV로 다른이름 저장하기
                    {
                        //
                        break;
                    }

                    default: break;
                }
            }
        }


        /// <summary>
        /// 클립보드 복사 버튼
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pr_btn31__Click(object sender, EventArgs e)
        {
            prCommonClipboardCopy(m_txb31);
        }
        #endregion


    }




}
