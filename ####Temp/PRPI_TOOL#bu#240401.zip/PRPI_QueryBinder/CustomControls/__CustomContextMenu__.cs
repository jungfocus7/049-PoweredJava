﻿using System;
using System.ComponentModel;
using System.Windows.Forms;




namespace PRPI_QueryBinder.CustomControls
{
    public sealed class CmsEx : ContextMenuStrip
    {
        public CmsEx(Form frm)
        {
            _frm = frm;
        }

        private Form _frm;
        private ImeMode _imb;


        protected override void OnOpening(CancelEventArgs e)
        {
            base.OnOpening(e);

            if (_frm.ActiveControl is Control ac)
            {
                _imb = ac.ImeMode;
                ac.ImeMode = ImeMode.Disable;
            }
        }

        protected override void OnClosing(ToolStripDropDownClosingEventArgs e)
        {
            base.OnClosing(e);

            if (_frm.ActiveControl is Control ac)
            {
                ac.ImeMode = _imb;
            }
        }

        protected override void OnMouseDown(MouseEventArgs mea)
        {
            base.OnMouseDown(mea);

            if (mea.Button != MouseButtons.Left)
                Close();
        }


        //protected override void OnPreviewKeyDown(PreviewKeyDownEventArgs e)
        //{
        //    base.OnPreviewKeyDown(e);

        //    Keys key = e.KeyData;
        //    if ((key >= Keys.D0) && (key <= Keys.D9)) { }
        //    else if ((key >= Keys.A) && (key <= Keys.Z)) { }
        //    else
        //    {
        //        Close();
        //    }
        //}

    }




    public static class MenuItemNames
    {
        public const string Tsn_1 = "tsn_1";
        public const string Tsn_2 = "tsn_2";
        public const string Tsn_3 = "tsn_3";
        public const string Tsn_4 = "tsn_4";
        public const string Tsn_5 = "tsn_5";
        public const string Tsn_6 = "tsn_6";
        public const string Tsn_7 = "tsn_7";
        public const string Tsn_8 = "tsn_8";
        public const string Tsn_9 = "tsn_9";
        public const string Tsn_0 = "tsn_0";

        public const string Tsn_a = "tsn_a";
        public const string Tsn_b = "tsn_b";
        public const string Tsn_c = "tsn_c";
        public const string Tsn_d = "tsn_d";
        public const string Tsn_e = "tsn_e";
        public const string Tsn_f = "tsn_f";
        public const string Tsn_g = "tsn_g";
        public const string Tsn_h = "tsn_h";
        public const string Tsn_i = "tsn_i";
        public const string Tsn_j = "tsn_j";
        public const string Tsn_k = "tsn_k";

        public const string Tsn_l = "tsn_l";
        public const string Tsn_m = "tsn_m";
        public const string Tsn_n = "tsn_n";
        public const string Tsn_o = "tsn_o";
        public const string Tsn_p = "tsn_p";
        public const string Tsn_q = "tsn_q";
        public const string Tsn_r = "tsn_r";
        public const string Tsn_s = "tsn_s";
        public const string Tsn_t = "tsn_t";
        public const string Tsn_u = "tsn_u";
        public const string Tsn_v = "tsn_v";
        public const string Tsn_w = "tsn_w";
        public const string Tsn_x = "tsn_x";
        public const string Tsn_y = "tsn_y";
        public const string Tsn_z = "tsn_z";
    }




    public sealed class Tsmi31 : ToolStripMenuItem
    {
        public Tsmi31(string text, string name, EventHandler clh)
        {
            Text = text;
            Name = name;
            _clh = clh;
            Click += _clh;
        }

        private EventHandler _clh;
    }




    public sealed class Tsmi41 : ToolStripMenuItem
    {
        public readonly string Rtg;

        public Tsmi41(string rtg, string ftx, string name)
        {
            Rtg = rtg;
            Text = $"{ftx}{Rtg}";
            Name = name;
        }
    }



    public sealed class Tsmi41Group : ToolStripMenuItem
    {
        private readonly string _ftg;
        private readonly Tsmi41[] m_arr;
        public const string Cbt_ItemSelected = "ItemSelected"; //CallbackType
        private readonly Action<string, Tsmi41> m_cb;
        private Tsmi41 m_dm;

        public Tsmi41Group(string ftg, string name, Tsmi41[] arr, Action<string, Tsmi41> cb)
        {
            _ftg = ftg;
            Text = _ftg;
            Name = name;
            m_arr = arr;
            m_cb = cb;

            DropDownItems.AddRange(m_arr);
            foreach (Tsmi41 mi in m_arr)
            {
                mi.Click += prItemsClick;
            }
        }

        private void prItemsClick(object sender, EventArgs e)
        {
            if (sender is Tsmi41 mi)
            {
                prChecked(mi);
            }
        }


        //private ToolStripItem m_owner;
        //private ToolStripItem prGetOwner(ToolStripMenuItem mi)
        //{
        //    if (m_owner == null)
        //    {
        //        m_owner = mi.OwnerItem;
        //    }
        //    return m_owner;
        //}


        private void prUnchecked()
        {
            if (m_dm != null)
            {
                m_dm.Checked = false;
                m_dm = null;
                Text = _ftg;
            }
        }


        private void prChecked(Tsmi41 mi)
        {
            prUnchecked();
            m_dm = mi;
            m_dm.Checked = true;

            string btp = m_dm.Rtg;
            Text = $"{_ftg}{btp}";

            //ToolStripItem tsi = prGetOwner(mi);
            //tsi.Text = m_dm.Text;
            //m_cb?.Invoke(Cbt_ItemSelected, mi);
            m_cb?.Invoke(Cbt_ItemSelected, mi);
        }


        public void SetChecked(string btp)
        {
            int si = -1;

            for (int l = m_arr.Length, i = 0; i < l; ++i)
            {
                Tsmi41 mi = m_arr[i];
                if (mi.Text.Contains(btp))
                {
                    si = i;
                    break;
                }
            }

            if ((si > -1) && (si < m_arr.Length))
            {
                prChecked(m_arr[si]);
            }
        }

    }

}
