﻿using Microsoft.VisualBasic;
using RootAppCommon;
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using System.Xml;




namespace PRPI_QueryBinder.DataProviders
{
    public static class QueryDataProvider
    {
        #region [ 00) 기본 항목들 ]
        /// <summary>
        /// 기본데이터 파일 경로
        /// </summary>
        private readonly static string _dqdfp;


        /// <summary>
        /// QueryData 디렉토리 경로
        /// </summary>
        private readonly static string _qddp;



        /// <summary>
        /// 현재 XML파일경로
        /// </summary>
        private static string _xfp;


        /// <summary>
        /// 현재 XML객체
        /// </summary>
        private static XmlDocument _xd;


        /// <summary>
        /// OpenFileDialog
        /// </summary>
        private static OpenFileDialog _ofd;


        /// <summary>
        /// SaveFileDialog
        /// </summary>
        private static SaveFileDialog _sfd;




        /// <summary>
        /// 초기화 생성자
        /// </summary>
        static QueryDataProvider()
        {
            _dqdfp = AppCommon.GetBasePath("QueryBinder__DefaultData.xml");
            //_qddp = AppCommon.GetBasePath("QueryDatas");
            _qddp = AppCommon.GetBasePath("..\\#쿼리xml모음");
            if (Directory.Exists(_qddp) == false)
            {
                try { Directory.CreateDirectory(_qddp); }
                catch { }
            }
        }


        public static string XmlFileName
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_xfp))
                    return string.Empty;
                else
                    return Path.GetFileName(_xfp);
            }
        }


        /// <summary>
        /// 코멘트 내용
        /// </summary>
        private static string _comment = string.Empty;
        public static string Comment
        {
            get { return _comment; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    _comment = string.Empty;
                else
                    _comment = value;
            }
        }


        /// <summary>
        /// 쿼리 내용
        /// </summary>
        private static string _query = string.Empty;
        public static string Query
        {
            get { return _query; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    _query = string.Empty;
                else
                    _query = value;
            }
        }


        /// <summary>
        /// 파리미터 내용
        /// </summary>
        private static string _parameters = string.Empty;
        public static string Parameters
        {
            get { return _parameters; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    _parameters = string.Empty;
                else
                    _parameters = value;
            }
        }


        /// <summary>
        /// 바인드 타입
        /// </summary>
        public const string Bt_QuestionMark = "QuestionMark";
        public const string Bt_StringFormat = "StringFormat";
        private static string _bindType = Bt_QuestionMark;
        public static string BindType
        {
            get { return _bindType; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    _bindType = Bt_QuestionMark;
                else if ((value == Bt_QuestionMark) || (value == Bt_StringFormat))
                {
                    if (value == _bindType) return;
                    else _bindType = value;
                }
            }
        }
        #endregion



        /// <summary>
        /// 빠른저장 파일경로 반환
        /// </summary>
        /// <returns></returns>
        public static string GetQuickFilePath()
        {
            string fnm = $"R{DateTime.Now.ToString("yyMMddHHmmssff")}.xml";            
            return Path.Combine(_qddp, fnm);
        }
        public static string GetQuickFilePath_csv()
        {
            string fnm = $"D{DateTime.Now.ToString("yyMMddHHmmssff")}.csv";
            return Path.Combine(_qddp, fnm);
        }



        /// <summary>
        /// 데이터 언로드
        /// </summary>
        public static void Unload()
        {
            if (_xfp == null) return;
            _xfp = null;
            _xd = null;
            Comment = string.Empty;
            Query = string.Empty;
            Parameters = string.Empty;
            BindType = string.Empty;
        }


        /// <summary>
        /// 데이터 로드
        /// </summary>
        /// <param name="xfp"></param>
        /// <returns></returns>
        public static bool Load(string xfp = null)
        {
            Unload();

            if (string.IsNullOrWhiteSpace(xfp))
                _xfp = _dqdfp;
            else
                _xfp = xfp;

            try
            {
                _xd = new XmlDocument();
                _xd.Load(_xfp);

                Comment = _xd.SelectSingleNode("Root/Comment").InnerText.Trim();
                Query = _xd.SelectSingleNode("Root/Query").InnerText.Trim();
                Parameters = _xd.SelectSingleNode("Root/Parameters").InnerText.Trim();
                BindType = _xd.SelectSingleNode("Root/Parameters").Attributes["BindType"].InnerText.Trim();

                return true;
            }
            catch (Exception ex)
            {
                Unload();

                //AppCommon.Alert(ex.ToString());
                AppCommon.Log(ex.ToString());

                return false;
            }
        }


        /// <summary>
        /// 데이터 로드 에즈
        /// </summary>
        /// <returns></returns>
        public static bool LoadAs()
        {
            if (_ofd == null)
            {
                _ofd = new OpenFileDialog()
                {
                    Title = "불러오기 할 xml파일 선택",
                    Multiselect = false,
                    DefaultExt = "xml",
                    Filter = "XML File (*.xml)|*.xml",
                    InitialDirectory = _qddp
                };
            }

            DialogResult tdr = _ofd.ShowDialog();
            if (tdr == DialogResult.OK)
            {
                string xfp = _ofd.FileName;
                if (File.Exists(xfp))
                {
                    return Load(xfp);
                }
            }

            return false;
        }




        /// <summary>
        /// 항목들 업데이트
        /// </summary>
        /// <param name="comment">코멘트 내용</param>
        /// <param name="query">쿼리 내용</param>
        /// <param name="parameters">파라미터 내용</param>
        /// <param name="btp">바인드 타입</param>
        public static void UpdateItems(string comment, string query, string parameters, string btp = null)
        {
            Comment = comment;
            Query = query;
            Parameters = parameters;
            if (btp != null) BindType = btp;
        }



        /// <summary>
        /// XML Template Root
        /// </summary>
        private readonly static string __xmltplrt = @"

<Root>
  <Comment>
<![CDATA[
{0}
]]>    
  </Comment>
  <Query>
<![CDATA[
{1}
]]>
  </Query>
  <Parameters BindType=""{3}"">
<![CDATA[
{2}
]]>
  </Parameters>
</Root>

        ".Trim();


        /// <summary>
        /// 데이터 세이브
        /// </summary>
        /// <param name="comment">Comment</param>
        /// <param name="query">Query</param>
        /// <param name="parameters">Parameters</param>
        /// <param name="btp">BindType</param>
        /// <param name="xfp">XmlFilePath</param>
        public static void Save(string xfp = null)
        {
            if (string.IsNullOrWhiteSpace(xfp))
                xfp = _dqdfp;

            try
            {
                string txt = string.Format(__xmltplrt, Comment, Query, Parameters, BindType);
                File.WriteAllText(xfp, txt);

                AppCommon.Alert($"{xfp}{Constants.vbNewLine}으로 저장됨.");
            }
            catch (Exception ex)
            {
                //AppCommon.Alert(ex.ToString());
                AppCommon.Log(ex.ToString());
            }
        }


        /// <summary>
        /// 데이터 세이브 에즈
        /// </summary>
        /// <param name="xfp"></param>
        public static void SaveAs()
        {
            if (_sfd == null)
            {
                _sfd = new SaveFileDialog()
                {
                    Title = "저장하기 할 xml파일 선택",
                    DefaultExt = "xml",
                    Filter = "XML File (*.xml)|*.xml",
                    InitialDirectory = _qddp,
                };
            }

            _sfd.FileName = $"R{DateTime.Now.ToString("yyMMddHHmmssff")}.xml";
            DialogResult tdr = _sfd.ShowDialog();
            if (tdr == DialogResult.OK)
            {
                string xfp = _sfd.FileName;
                Save(xfp);
            }
        }


        /// <summary>
        /// 데이터 폴더 열기
        /// </summary>
        public static void OpenFolder()
        {
            try
            {
                Process.Start(_qddp);
            }
            catch { }
        }


        /// <summary>
        /// 현재 열린 파일 탐색기 표시
        /// </summary>
        public static void OpenFolderForNowFile()
        {
            try
            {
                if (File.Exists(_xfp))
                {
                    string args = $"/e, /select, {_xfp}";
                    Process.Start("explorer", args);
                }
            }
            catch { }
        }

    }

}
