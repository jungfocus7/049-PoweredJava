﻿Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports PRPI_CaseNormal
Imports PRPI_QueryBinder
Imports PRPI_SqlMaker
Imports RootAppCommon.Controls
Imports RootAppCommon.Managers
Imports RootAppCommon.Models




Public NotInheritable Class MainForm
    Public Sub New()
        ' 디자이너에서 이 호출이 필요합니다.
        InitializeComponent()

        ' InitializeComponent() 호출 뒤에 초기화 코드를 추가하세요.

    End Sub



    Protected Overrides Sub OnLoad(e As EventArgs)
        MyBase.OnLoad(e)

        Text = "PRPI_TOOL  ver 1.03c"
        DoubleBuffered = True
        AlignBottomRight(10, 10)


        m_lstv.BeginUpdate()
        m_lstv.Font = New Font(m_lstv.Font, FontStyle.Bold)
        m_lstv.View = View.Details
        m_lstv.HideSelection = False
        m_lstv.FullRowSelect = True
        m_lstv.HeaderStyle = ColumnHeaderStyle.Nonclickable

        Dim ch As New ColumnHeader With {
            .Text = "번호",
            .Width = 40,
            .TextAlign = HorizontalAlignment.Left
        }
        m_lstv.Columns.Add(ch)
        ch = New ColumnHeader With {
            .Text = "앱 이름",
            .Width = 200,
            .TextAlign = HorizontalAlignment.Left
        }
        m_lstv.Columns.Add(ch)

        Dim lf As New Font(m_lstv.Font, FontStyle.Regular)
        Dim lvi As New ListViewItem With {
            .Text = "01)",
            .Font = lf
        }
        lvi.SubItems.Add("PRPI_QueryBinder")
        m_lstv.Items.Add(lvi)
        lvi = New ListViewItem With {
            .Text = "02)",
            .Font = lf
        }
        lvi.SubItems.Add("PRPI_CaseNormal")
        m_lstv.Items.Add(lvi)
        lvi = New ListViewItem With {
            .Text = "03)",
            .Font = lf
        }
        lvi.SubItems.Add("PRPI_SqlMaker")
        m_lstv.Items.Add(lvi)
        m_lstv.EndUpdate()
        m_lstv.SetDoubleBuffered(True)
        m_lstv.Items(0).Selected = True

        'pr_btn31__Click(Nothing, Nothing)
    End Sub


    Protected Overrides Sub OnShown(e As EventArgs)
        MyBase.OnShown(e)

        'pr_btn31__Click(Nothing, Nothing)
    End Sub


    Private Sub pr_btn31__Click(sender As Object, e As EventArgs) Handles m_btn31.Click
        Try
            Dim slvis As ListView.SelectedListViewItemCollection = m_lstv.SelectedItems
            Dim lvi As ListViewItem = slvis(0)

            Dim name As String = lvi.SubItems(1).Text
            Dim fi As FormInfo = FormManager.GetFormInfo(name)
            If fi.RefForm Is Nothing Then
                If name = "PRPI_QueryBinder" Then
                    fi.RefForm = New QueryBinderForm()
                ElseIf name = "PRPI_CaseNormal" Then
                    fi.RefForm = New CaseNormalForm()
                ElseIf name = "PRPI_SqlMaker" Then
                    fi.RefForm = New SqlMakerForm()
                End If
            End If

            Try
                fi.RefForm.Show(Me)
            Catch
                fi.RefForm.WindowState = FormWindowState.Normal
            End Try
        Catch
        End Try
    End Sub


    Private Sub pr_lstv__DoubleClick(sender As Object, e As EventArgs) Handles m_lstv.DoubleClick
        pr_btn31__Click(Nothing, Nothing)
    End Sub

End Class
