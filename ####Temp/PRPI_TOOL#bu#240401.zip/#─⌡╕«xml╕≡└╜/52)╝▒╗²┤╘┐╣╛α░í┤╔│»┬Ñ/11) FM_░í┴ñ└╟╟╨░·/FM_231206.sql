WITH XR1 AS ( /* SQLID=kr.amc.amis.wa.wj.op.store.mapper.WaWjOpDrOpadSchdCreatBrkdwnMapper.retrieveInqryYymmDtConfm3" */
    SELECT
        COUNT(*) AS CNT
    FROM (
        SELECT PATNO, VIST_SN
        FROM WJAPMPATN
        WHERE PATNO = '14210565'
            AND (MDEX_SRVC_CD NOT IN ('C','N','Q','A','V','T','Z','M')
                AND MDEX_DIV_CD != 'G')
            AND VALD_YN = 'Y'
            AND CANCEL_TTRET_YN = 'N'
        )
)
, XR2 AS (
    SELECT
           COUNT(*) AS CNT
      FROM ( SELECT PATN.PATNO, PATN.VIST_SN
               FROM WJDRMDEPT DEPT
                  , WJDRMDEPT DEP2
                  , WJAPMPATN PATN  --V_WPATOPAT
                  , WJAPMPATN PAT2
              WHERE DEPT.MDDP_CD = 'END'
                AND DEPT.VALD_YN = 'Y'
                AND DEP2.FR_SAME_CONFM_MDDP_CD = DEPT.FR_SAME_CONFM_MDDP_CD
                AND DEP2.VALD_YN = 'Y'
                AND PATN.PATNO = '14210565'
                AND PATN.MDDP_CD = DEP2.MDDP_CD
                --------------------------
                AND PATN.MDEX_DIV_CD = 'O'
                AND PATN.MDEX_SRVC_CD NOT IN ('Z', 'M') -- �Կ������� ���� �ʿ�
                AND PATN.VALD_YN = 'Y'
                AND PATN.CANCEL_TTRET_YN = 'N'
                --------------------------
                AND PAT2.PATNO = PATN.PATNO
                AND PAT2.VIST_SN = PATN.VIST_SN
              UNION ALL
             SELECT PATN.PATNO, PATN.VIST_SN
               FROM WJDRMDEPT DEPT
                  , WJDRMDEPT DEP2
                  , WJAPMPATN PATN  --V_WPATEPAT
              WHERE DEPT.MDDP_CD = 'END'
                AND DEPT.VALD_YN = 'Y'
                AND DEP2.FR_SAME_CONFM_MDDP_CD = DEPT.FR_SAME_CONFM_MDDP_CD
                AND DEP2.VALD_YN = 'Y'
                AND PATN.PATNO = '14210565'
                AND PATN.MDDP_CD = DEP2.MDDP_CD
                --------------------------
                AND PATN.MDEX_DIV_CD = 'E'
                AND PATN.VALD_YN = 'Y'
                AND PATN.CANCEL_TTRET_YN = 'N'
                --------------------------
             UNION ALL
             SELECT PATN.PATNO, PATN.VIST_SN
               FROM WJDRMDEPT DEPT
                  , WJDRMDEPT DEP2
                  , WJAPMPATN PATN  --V_WPATITPT
                  , WJAPDDEPT PDPT  --V_WPATDEPT
              WHERE DEPT.MDDP_CD = 'END'
                AND DEPT.VALD_YN = 'Y'
                AND DEP2.FR_SAME_CONFM_MDDP_CD = DEPT.FR_SAME_CONFM_MDDP_CD
                AND DEP2.VALD_YN = 'Y'
                AND PATN.PATNO = '14210565'
                --------------------------
                AND PATN.VALD_YN = 'Y'
                AND PATN.MDEX_DIV_CD = 'I'
                AND PATN.DCHRG_DT != '99991231'
                AND PATN.CANCEL_TTRET_YN = 'N'
                --------------------------
                AND PDPT.PATNO = PATN.PATNO
                AND PDPT.VIST_SN = PATN.VIST_SN
                AND PDPT.MDDP_CD = DEP2.MDDP_CD
                --------------------------
                AND PDPT.MDDP_APHYS_SN > 0
                AND PDPT.MAMM_YN = 'Y'
                AND PDPT.VALD_YN = 'Y'
                --------------------------
             UNION ALL
             SELECT PATN.PATNO, PATN.VIST_SN
               FROM WJDRMDEPT DEPT
                  , WJDRMDEPT DEP2
                  , V_WJIPRIHPT PATN
                  , WJAPDDEPT PDPT  --V_WPATDEPT
              WHERE DEPT.MDDP_CD = 'END'
                AND DEPT.VALD_YN = 'Y'
                AND DEP2.FR_SAME_CONFM_MDDP_CD = DEPT.FR_SAME_CONFM_MDDP_CD
                AND DEP2.VALD_YN = 'Y'
                AND PATN.PATNO = '14210565'
                AND PDPT.PATNO = PATN.PATNO
                AND PDPT.VIST_SN = PATN.VIST_SN
                AND PDPT.MDDP_CD = DEP2.MDDP_CD
                --------------------------
                AND PDPT.MDDP_APHYS_SN > 0
                AND PDPT.MAMM_YN = 'Y'
                AND PDPT.VALD_YN = 'Y'
               --------------------------
         )
)
SELECT 
    CASE
        WHEN XR1.CNT = '0'
            THEN '1'  --��ȯ
        WHEN XR2.CNT = '0'
            THEN '2'  --����
        ELSE '3'      --���� OR ����  
    END AS IMCD
FROM XR1, XR2
;



------------------------------------------------------------------------------------------------
SELECT * FROM WPPIMINFO
WHERE PAT_NM = '�̽±�';
-- 14210565
SELECT * FROM V_WJAPMPATN
;










