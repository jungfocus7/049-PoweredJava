﻿using System.Drawing;
using System.Windows.Forms;




namespace RootAppCommon.Controls
{
    public static class FormExtension
    {
        /// <summary>
        /// 폼을 우측, 아래로 정렬
        /// </summary>
        /// <param name="frm"></param>
        /// <param name="ax"></param>
        /// <param name="ay"></param>
        public static void AlignBottomRight(this Form frm, int ax = 40, int ay = 40)
        {
            // 모니터다 듀얼 이상일때
            Screen tcs = Screen.FromPoint(Cursor.Position);
            Rectangle tsb = tcs.WorkingArea;
            Point tlp = new Point(tsb.Right, tsb.Bottom);
            Size tws = frm.Size;
            tlp.Offset(-(tws.Width + ax), -(tws.Height + ay));
            frm.Location = tlp;
        }


        /// <summary>
        /// 리사이즈에 때른 렌더링 최소화
        /// </summary>
        /// <param name="frm"></param>
        public static void ResizeRenderingPass(this Form frm)
        {
            frm.ResizeBegin += delegate
            {
                frm.SuspendLayout();
            };

            frm.ResizeEnd += delegate
            {
                frm.ResumeLayout(true);
            };
        }
    }
}
