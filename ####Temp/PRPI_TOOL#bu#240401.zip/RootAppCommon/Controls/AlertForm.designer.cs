﻿namespace RootAppCommon.Controls
{
    partial class AlertForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_txbMain = new System.Windows.Forms.TextBox();
            this.m_btnNo = new System.Windows.Forms.Button();
            this.m_btnYes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // m_txbMain
            // 
            this.m_txbMain.Location = new System.Drawing.Point(12, 12);
            this.m_txbMain.Multiline = true;
            this.m_txbMain.Name = "m_txbMain";
            this.m_txbMain.ReadOnly = true;
            this.m_txbMain.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_txbMain.Size = new System.Drawing.Size(476, 239);
            this.m_txbMain.TabIndex = 0;
            this.m_txbMain.WordWrap = false;
            // 
            // m_btnNo
            // 
            this.m_btnNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.m_btnNo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btnNo.Location = new System.Drawing.Point(408, 258);
            this.m_btnNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btnNo.Name = "m_btnNo";
            this.m_btnNo.Size = new System.Drawing.Size(80, 29);
            this.m_btnNo.TabIndex = 10;
            this.m_btnNo.Text = "취소";
            this.m_btnNo.UseVisualStyleBackColor = true;
            // 
            // m_btnYes
            // 
            this.m_btnYes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.m_btnYes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btnYes.Location = new System.Drawing.Point(322, 258);
            this.m_btnYes.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btnYes.Name = "m_btnYes";
            this.m_btnYes.Size = new System.Drawing.Size(80, 29);
            this.m_btnYes.TabIndex = 11;
            this.m_btnYes.Text = "확인";
            this.m_btnYes.UseVisualStyleBackColor = true;
            // 
            // AlertForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 300);
            this.Controls.Add(this.m_btnYes);
            this.Controls.Add(this.m_btnNo);
            this.Controls.Add(this.m_txbMain);
            this.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "AlertForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "AlertForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox m_txbMain;
        private System.Windows.Forms.Button m_btnNo;
        private System.Windows.Forms.Button m_btnYes;
    }
}