﻿using System;
using System.Windows.Forms;




namespace RootAppCommon.Controls
{
    public partial class AlertForm : Form
    {
        public static DialogResult OpenDialog(
            IWin32Window owner, string title, string text, HorizontalAlignment textAlign = HorizontalAlignment.Center)
        {
            DialogResult rdr = DialogResult.None;
            using (AlertForm aform = new AlertForm())
            {
                aform.m_txbMain.TextAlign = textAlign;
                aform.m_txbMain.Text = text;
                rdr = aform.ShowDialog(owner);
            }

            return rdr;
        }





        public AlertForm()
        {
            InitializeComponent();

            m_txbMain.Clear();
            m_btnYes.Click += pr_btnYes__Click;
            m_btnNo.Click += pr_btnNo__Click;
        }



        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
        }


        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            m_btnYes.Focus();
        }



        private void pr_btnYes__Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Yes;
            Close();
        }



        private void pr_btnNo__Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
            Close();
        }



        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Close();
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

    }

}
