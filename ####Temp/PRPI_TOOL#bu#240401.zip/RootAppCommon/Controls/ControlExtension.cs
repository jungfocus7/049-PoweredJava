﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;




namespace RootAppCommon.Controls
{
    public static class ControlExtension
    {
        public static void SetDoubleBuffered(this Control ctr, bool b)
        {
            Type tp = ctr.GetType();
            PropertyInfo pi = tp.GetProperty(
                "DoubleBuffered" , BindingFlags.Instance | BindingFlags.NonPublic);
            pi.SetValue(ctr, b, null);
        }
    }
}
