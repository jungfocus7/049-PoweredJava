﻿using RootAppCommon.Controls;
using RootAppCommon.Models;
using System;
using System.IO;
using System.Windows.Forms;




namespace RootAppCommon
{
    public static class AppCommon
    {
        static AppCommon()
        {
            CommandLineArgs = Environment.GetCommandLineArgs();
            StartupFilePath = CommandLineArgs[0];
            StartupPath = Path.GetDirectoryName(StartupFilePath);

            //prQueryTester();
        }


        /// <summary>
        /// 커맨드라인 인자 배열
        /// </summary>
        public static string[] CommandLineArgs { get; private set; }


        /// <summary>
        /// 어플리케이션 시작 파일 경로
        /// </summary>
        public static string StartupFilePath { get; private set; }


        /// <summary>
        /// 어플리케이션 시작 경로
        /// </summary>
        public static string StartupPath { get; private set; }



        /// <summary>
        /// 시작을 기준으로 한 경로 만들기
        /// </summary>
        /// <returns></returns>
        public static string GetBasePath(string subPath)
        {
            string rp = Path.Combine(StartupPath, subPath);
            return rp;
        }



        /// <summary>
        /// 디버그용 로그
        /// </summary>
        public static void Log(string txt)
        {
            Console.WriteLine(txt);
        }





        /// <summary>
        /// 메인폼 참조
        /// </summary>
        private static Form _mainForm;
        public static Form MainForm
        {
            get
            {
                if (_mainForm == null)
                {
                    foreach (Form frm in Application.OpenForms)
                    {
                        if (frm.Name == "MainForm")
                        {
                            _mainForm = frm;
                            break;
                        }
                    }
                }
                return _mainForm;
            }
        }





        /// <summary>
        /// 공통 타이틀
        /// </summary>
        private const string _awcTitle = "알림";


        /// <summary>
        /// 메세지창 띄우기
        /// </summary>
        /// <param name="owner"></param>
        /// <param name="title"></param>
        /// <param name="text"></param>
        /// <param name="textAlign"></param>
        public static void Alert(
            IWin32Window owner, string title, string text, HorizontalAlignment textAlign = HorizontalAlignment.Center)
        {
            if (owner == null)
                owner = MainForm;
            AlertForm.OpenDialog(owner, title, text, textAlign);
        }


        /// <summary>
        /// 메세지창 띄우기
        /// </summary>
        /// <param name="text"></param>
        public static void Alert(string text)
        {
            IWin32Window owner = Form.ActiveForm;
            if (owner == null) owner = MainForm;
            Alert(owner, _awcTitle, text, HorizontalAlignment.Center);
        }


        /// <summary>
        /// 메세지창 띄우기
        /// </summary>
        /// <param name="text"></param>
        public static void Alert(IWin32Window owner, string text)
        {
            Alert(owner, _awcTitle, text, HorizontalAlignment.Center);
        }




        //        private static void prQueryTester()
        //        {
        //            string connStr = @"
        //Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.91.10.24)(PORT=1522)))
        //    (CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=EDUC))); User Id = amisman; Password = amisman123;".Trim();

        //            OracleConnection oconn = null;
        //            OracleDataReader odr = null;
        //            try
        //            {
        //                oconn = new OracleConnection(connStr);
        //                oconn.Open();

        //                OracleCommand ocmd = new OracleCommand()
        //                {
        //                    Connection = oconn,
        //                    CommandType = CommandType.Text,
        //                    CommandText = @"
        //SELECT *
        //FROM V_WPPIMINFO
        //WHERE PATNO = '18355996'

        //                    ".Trim(),
        //                    //BindByName = false
        //                };

        //                odr = ocmd.ExecuteReader();
        //                DataTable tdt = new DataTable();
        //                tdt.Load(odr);
        //            }
        //            catch (Exception ex)
        //            {
        //            }
        //            finally
        //            {
        //                odr.Close();
        //                oconn.Close();
        //            }
        //        }


    }

}
