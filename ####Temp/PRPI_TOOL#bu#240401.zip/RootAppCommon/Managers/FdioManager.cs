﻿using System;
using System.IO;




namespace RootAppCommon.Managers
{
    //public static class FdioManager
    //{
    //    /// <summary>
    //    /// 빠른저장 파일경로 반환
    //    /// </summary>
    //    /// <returns></returns>
    //    public static string GetQuickFilePath()
    //    {
    //        string fnm = $"R{DateTime.Now.ToString("yyMMddHHmmssff")}.xml";
    //        return Path.Combine(_qddp, fnm);
    //    }
    //}
}
