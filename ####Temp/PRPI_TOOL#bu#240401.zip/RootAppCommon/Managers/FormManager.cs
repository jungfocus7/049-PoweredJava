﻿using RootAppCommon.Models;




namespace RootAppCommon.Managers
{
    public static class FormManager
    {
        /// <summary>
        /// SubFormInfoMap
        /// </summary>
        private static readonly FormInfoMap _sfim = new FormInfoMap();

        /// <summary>
        /// 자식 폼 정보 가져오기
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static FormInfo GetFormInfo(string name)
        {
            if (_sfim.ContainsKey(name))
                return _sfim[name];
            else
            {
                FormInfo rfi = new FormInfo(name);
                _sfim.Add(name, rfi);
                return rfi;
            }
        }

    }

}
