﻿using Oracle.ManagedDataAccess.Client;
using RootAppCommon.DataExtentions;
using System;
using System.Data;




namespace RootAppCommon.Managers
{
    public static class DataManager
    {
        #region "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 91) 기본 설정"
        /// <summary>
        /// 운영(주의)
        /// </summary>
        public static readonly string _ConnStr = @"
        Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.91.10.23)(PORT=1521)))
            (CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=PROD))); User Id = amisman; Password = amisman123;".Trim();


        ///// <summary>
        ///// 실습
        ///// </summary>        
        //public static readonly string _ConnStr = @"
        //Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.91.10.24)(PORT=1522)))
        //    (CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=EDUC))); User Id = amisman; Password = amisman123;".Trim();
        #endregion





        #region "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 92) 커넥션 생성"
        private static OracleConnection _oconn = null;

        public static void Close()
        {
            if (_oconn == null) return;
            try { _oconn.Close(); }
            catch { }
            _oconn = null;
        }

        public static OracleConnection Open()
        {
            OracleConnection roc = null;
            try
            {
                _oconn = new OracleConnection(_ConnStr);
                _oconn.Open();
                roc = _oconn;
            }
            catch
            {
                Close();
                roc = null;
            }

            return roc;
        }
        #endregion






        #region "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 01) 데이터 작업 영역"
        private static DataTable _lastData;
        public static void ClearLastData()
        {
            _lastData.Release();
        }
        public static DataTable GetLastData()
        {
            return _lastData;
        }


        public static DataTable SelectData(string query)
        {
            if (string.IsNullOrWhiteSpace(query)) return null;
            query = query.Trim();
            //query = query.Replace(";", string.Empty);
            if (query.StartsWith("SELECT", true, null) == false)
                return null;

            DataTable rdt = null;
            Open();
            OracleDataReader odr = null;
            try
            {
                OracleCommand ocmd = new OracleCommand()
                {
                    Connection = _oconn,
                    CommandType = CommandType.Text,
                    CommandText = query
                };
                odr = ocmd.ExecuteReader();
                if (true)
                {
                    rdt = new DataTable();
                    rdt.Load(odr);
                    ClearLastData();
                    _lastData = rdt;
                }
            }
            catch (Exception ex)
            {
                AppCommon.Log(ex.ToString());
            }

            if (odr != null)
            {
                try { odr.Close(); }
                catch { }
                odr = null;
            }
            Close();

            return rdt;
        } 
        #endregion

    }
}
