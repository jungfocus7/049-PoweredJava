﻿namespace RootAppCommon.DataExtentions
{
    public static class StringExtention
    {
        public static char CharAt(this string str, int i)
        {
            if (string.IsNullOrWhiteSpace(str))
                return char.MinValue;

            int j = (i < 0) ? str.Length + i : i;
            return str[j];
        }
    }
}
