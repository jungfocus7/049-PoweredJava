﻿using System.Data;




namespace RootAppCommon.DataExtentions
{
    public static class DataTableExtention
    {
        /// <summary>
        /// DataTable 빈객체인가 여부
        /// </summary>
        /// <param name="table"></param>
        /// <returns></returns>
        public static bool IsEmpty(this DataTable table)
        {
            if (table == null) return true;
            if (table.Rows.Count == 0) return true;
            return false;
        }



        /// <summary>
        /// DataTable 사용가능한가 여부
        /// </summary>
        /// <param name="table"></param>
        /// <returns></returns>
        public static bool NotEmpty(this DataTable table)
        {
            if (table == null) return false;
            if (table.Rows.Count == 0) return false;
            return true;
        }



        /// <summary>
        /// DataTable 소거용
        /// </summary>
        /// <param name="table"></param>
        public static void Release(this DataTable table)
        {
            if (table == null) return;

            try
            {
                table.Rows.Clear();
                table.Columns.Clear();
            }
            catch { }
            try
            {
                table.Clear();
                table.Dispose();
            }
            catch { }
        }

    }
}
