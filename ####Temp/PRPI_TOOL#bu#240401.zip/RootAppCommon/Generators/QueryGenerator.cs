﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;




namespace RootAppCommon.Generators
{
    public static class QueryGenerator
    {
        #region [ 00) 공톰 함수들 ]
        public const string QtSelect = "SELECT";
        public const string QtUpdate = "UPDATE";
        public const string QtInsert = "INSERT";
        public const string QtDelete = "DELETE";
        private static string _qtp;
        public static string QueryTypes
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_qtp))
                {
                    try
                    {
                        Type tp = typeof(QueryGenerator);
                        FieldInfo[] fia = tp.GetFields(BindingFlags.Public | BindingFlags.Static);
                        fia = fia.Where(tx => tx.Name.StartsWith("Qt")).ToArray();

                        StringBuilder msb = new StringBuilder();
                        foreach (FieldInfo fi in fia)
                        {
                            string tv = fi.GetValue(null).ToString();
                            msb.AppendLine(tv);
                        }
                        _qtp = msb.ToString();
                    }
                    catch { }
                }

                return _qtp;
            }
        }



        private static string[] prGetColumns(string ls)
        {
            if (string.IsNullOrWhiteSpace(ls)) return null;
            string[] txa = ls.Split(new string[] { Constants.vbTab }, StringSplitOptions.None);
            return txa;
        }
        private static string[] prGetRow(string ls)
        {
            return prGetColumns(ls);
        }
        private static (string[], List<string[]>) prExtractColsRows(string txt)
        {
            string[] lsa = txt.Split(new string[] { Constants.vbNewLine }, StringSplitOptions.RemoveEmptyEntries);
            if (lsa.Length < 2)
            {
                AppCommon.Alert("행(row)가 2개 이상이어야 함");
                return (null, null);
            }


            string err = null;

            string[] cols = null;
            List<string[]> rows = null;
            foreach (string ls in lsa)
            {
                if (cols == null)
                {
                    cols = prGetColumns(ls);
                    if (cols == null)
                    {
                        err = "컬럼이 잘못됨";
                        break;
                    }
                }
                else
                {
                    string[] row = prGetRow(ls);
                    if ((row == null) || (row.Length != cols.Length))
                    {
                        err = "로우가 잘못됨";
                        break;
                    }
                    else
                    {
                        if (rows == null)
                            rows = new List<string[]>();
                        rows.Add(row);
                    }
                }
            }

            if (string.IsNullOrWhiteSpace(err) == false)
            {
                AppCommon.Alert(err);
                return (null, null);
            }
            else
            {
                return (cols, rows);
            }
        }



        private const string _drx01 = "  {0}";
        private const string _drx02 = "  , {0}";

        private const string _drx03 = "  {0} = '{1}'";
        private const string _drx04 = "  {0} IS NULL";
        private const string _drx05 = "  AND {0} = '{1}'";
        private const string _drx06 = "  AND {0} IS NULL";

        private const string _drx07 = "  {0} = '{1}'";
        private const string _drx08 = "  {0} = NULL";
        private const string _drx09 = "  , {0} = '{1}'";
        private const string _drx10 = "  , {0} = NULL";

        private const string _drx11 = "  '{0}'";
        private const string _drx12 = "  , '{0}'";
        private const string _drx13 = "  , NULL";


        /// <summary>
        /// 키밸류, 체크해서 Cond 반환
        /// </summary>
        /// <param name="tx"></param>
        /// <returns></returns>
        private static string prGetCondStr(bool bFirst, string tk, string tv)
        {
            if (bFirst)
            {
                if (string.IsNullOrWhiteSpace(tv) == false)
                    return string.Format(_drx03, tk, tv);
                else
                    return string.Format(_drx05, tk);

            }
            else
            {
                if (string.IsNullOrWhiteSpace(tv) == false)
                    return string.Format(_drx05, tk, tv);
                else
                    return string.Format(_drx06, tk);
            }
        }


        /// <summary>
        /// 키밸류, 체크해서 Assign 반환
        /// </summary>
        /// <param name="tx"></param>
        /// <returns></returns>
        private static string prGetAssignStr(bool bFirst, string tk, string tv)
        {
            if (bFirst)
            {
                if (string.IsNullOrWhiteSpace(tv) == false)
                    return string.Format(_drx07, tk, tv);
                else
                    return string.Format(_drx08, tk);

            }
            else
            {
                if (string.IsNullOrWhiteSpace(tv) == false)
                    return string.Format(_drx09, tk, tv);
                else
                    return string.Format(_drx10, tk);
            }
        }



        /// <summary>
        /// (Key)값 만들기 1
        /// </summary>
        /// <returns></returns>
        private static string prGetKey_1(string[] tva)
        {
            StringBuilder tsb = new StringBuilder();
            bool bFirst = true;
            foreach (string tv in tva)
            {
                if (bFirst)
                {
                    tsb.AppendLine(string.Format(_drx01, tv));
                    bFirst = false;
                }
                else
                {
                    tsb.AppendLine(string.Format(_drx02, tv));
                }
            }

            return tsb.ToString();
        }


        /// <summary>
        /// (Key and Value)값 만들기 1
        /// </summary>
        /// <returns></returns>
        private static string prGetKeyAndValue_1(string[] tka, string[] tva)
        {
            StringBuilder tsb = new StringBuilder();
            int i = 0;
            foreach (string tk in tka)
            {
                string tx = prGetCondStr(i == 0, tk, tva[i]);
                tsb.AppendLine(tx);
                ++i;
            }

            return tsb.ToString();
        }


        /// <summary>
        /// (Key and Value)값 만들기 2
        /// </summary>
        /// <returns></returns>
        private static string prGetKeyAndValue_2(string[] tka, string[] tva)
        {
            StringBuilder tsb = new StringBuilder();
            int i = 0;
            foreach (string tk in tka)
            {
                string tx = prGetAssignStr(i == 0, tk, tva[i]);
                tsb.AppendLine(tx);
                ++i;
            }

            return tsb.ToString();
        }


        /// <summary>
        /// (Value)값 만들기 1
        /// </summary>
        /// <returns></returns>
        private static string prGetValue_1(string[] tva)
        {
            StringBuilder tsb = new StringBuilder();
            bool bFirst = true;
            foreach (string tv in tva)
            {
                if (bFirst)
                {
                    if (string.IsNullOrWhiteSpace(tv) == false)
                        tsb.AppendLine(string.Format(_drx11, tv));
                    else
                        tsb.AppendLine(_drx13);
                    bFirst = false;
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(tv) == false)
                        tsb.AppendLine(string.Format(_drx12, tv));
                    else
                        tsb.AppendLine(_drx13);
                }
            }

            return tsb.ToString();
        }
        #endregion




        #region [ 01) SELECT 쿼리만들기 ]
        private readonly static string _Sql_Select = @"
SELECT
{0}
FROM {1}
WHERE
{2}
;
        ".Trim();
        public static string MakeSelect(string txt, string tnm)
        {
            (string[] cols, List<string[]> rows) = prExtractColsRows(txt);
            if ((cols == null) || (rows == null)) return null;

            StringBuilder msb = new StringBuilder();
            foreach (string[] row in rows)
            {
                string tp1 = prGetKey_1(cols);
                string tp2 = tnm;
                string tp3 = prGetKeyAndValue_1(cols, row);

                string rsql = string.Format(_Sql_Select, tp1, tp2, tp3);
                msb.AppendLine(rsql);
            }
            return msb.ToString();
        }
        #endregion




        #region [ 02) UPDATE 쿼리만들기 ]
        private readonly static string _Sql_Update = @"
UPDATE
{0}
SET
{1}
WHERE
{2}
;
        ".Trim();
        public static string MakeUpdate(string txt, string tnm)
        {
            (string[] cols, List<string[]> rows) = prExtractColsRows(txt);
            if ((cols == null) || (rows == null)) return null;

            StringBuilder msb = new StringBuilder();
            foreach (string[] row in rows)
            {
                string tp1 = tnm;
                string tp2 = prGetKeyAndValue_2(cols, rows[0]);
                string tp3 = prGetKeyAndValue_1(cols, rows[0]);

                string rsql = string.Format(_Sql_Update, tp1, tp2, tp3);
                msb.AppendLine(rsql);
            }
            return msb.ToString();
        }
        #endregion




        #region [ 03) INSERT 쿼리만들기 ]
        private readonly static string _Sql_Insert = @"
INSERT
INTO {0}
(
{1}
)
VALUES
(
{2}
)
;
        ".Trim();
        public static string MakeInsert(string txt, string tnm)
        {
            (string[] cols, List<string[]> rows) = prExtractColsRows(txt);
            if ((cols == null) || (rows == null)) return null;

            StringBuilder msb = new StringBuilder();
            foreach (string[] row in rows)
            {
                string tp1 = tnm;
                string tp2 = prGetKey_1(cols);
                string tp3 = prGetValue_1(rows[0]);

                string rsql = string.Format(_Sql_Insert, tp1, tp2, tp3);
                msb.AppendLine(rsql);
            }
            return msb.ToString();
        }
        #endregion




        #region [ 05) DELETE 쿼리만들기 ]
        private readonly static string _Sql_Delete = @"
DELETE
FROM {0}
WHERE
{1}
;
        ".Trim();
        public static string MakeDelete(string txt, string tnm)
        {
            (string[] cols, List<string[]> rows) = prExtractColsRows(txt);
            if ((cols == null) || (rows == null)) return null;

            StringBuilder msb = new StringBuilder();
            foreach (string[] row in rows)
            {
                string tp1 = tnm;
                string tp2 = prGetKeyAndValue_1(cols, rows[0]);

                string rsql = string.Format(_Sql_Delete, tp1, tp2);
                msb.AppendLine(rsql);
            }
            return msb.ToString();
        }
        #endregion
    }
}
