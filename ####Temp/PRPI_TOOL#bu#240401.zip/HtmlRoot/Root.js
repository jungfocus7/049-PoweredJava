

const _btnTester = document.getElementById('btnTester');
_btnTester.addEventListener('click', (e) => {
    const dsm = _btnTester.dataset;
    console.log(dsm, dsm.nameGateWay);
});















// import { hfScrollWave } from "./hjs/hfscrw.js";



// // const _rootCont = document.getElementById('rootCont');

// const _scrwCont = document.getElementById('scrwCont');
// const _scrwThumb = document.getElementById('scrwThumb');

// const _scrollWave = new hfScrollWave(_scrwCont, _scrwThumb);


// const _btnTester = document.getElementById('btnTester');
// _btnTester.addEventListener('click', (e) => {
//     _scrollWave.updateRect();
// });







// _scrollWave.addEventListener()
// console.log(_scrollWave);

// const _rctCont = _scrwCont.getBoundingClientRect();
// const _rctThumb = _scrwThumb.getBoundingClientRect();






// import { fn_updateElementPosition } from "./js/SubTools.js";
// import { fn_updateElementPosition } from "./hjs/hfscrw.js";



// // const _rootCont = document.getElementById('rootCont');

// const _scrwCont = document.getElementById('scrwCont');
// const _scrwThumb = document.getElementById('scrwThumb');

// const _rctCont = _scrwCont.getBoundingClientRect();
// const _rctThumb = _scrwThumb.getBoundingClientRect();




// const _MouseMove = 'mousemove';
// const _Blur = 'blur';
// const _MouseUp = 'mouseup';
// const _MouseDown = 'mousedown';
// const _Resize = 'resize';
// const _Scroll = 'scroll';


// const _gdo = Object.seal({
//     bmd: false,
//     mdx: -1, mdy: -1
// });


// const fn_mouseUp = (e) => {
//     if (_gdo.bmd === false) return;
//     window.removeEventListener(_MouseMove, fn_mouseMove);
//     window.removeEventListener(_MouseUp, fn_mouseUp);
//     window.removeEventListener(_Blur, fn_mouseUp);
//     _gdo.bmd = false;
// };


// // const fn_setElementPosition = (el, tx, ty) => {
// //     const st1 = _scrwThumb.style;
// //     st1.setProperty('left', `${tx}px`);
// //     st1.setProperty('top', `${ty}px`);
// //     // console.log(st1.getPropertyValue('left') == '');
// // };
// const fn_mouseMove = (e) => {
//     const bx = 0;
//     const by = 0;
//     const ex = _rctCont.width - _rctThumb.width;
//     const ey = _rctCont.height - _rctThumb.height;

//     let mx = (e.clientX - _rctCont.left) - 20;
//     let my = (e.clientY - _rctCont.top) - 20;

//     if (mx < bx) mx = bx;
//     else if (mx > ex) mx = ex;
//     if (my < by) my = by;
//     else if (my > ey) my = ey;
//     // console.log(mx, my);

//     fn_updateElementPosition(_scrwThumb, mx, my);
// };


// const fn_mouseDown = (e) => {
//     if (e.button === 0) {
//         if (_gdo.bmd === true) return;
//         window.addEventListener(_MouseMove, fn_mouseMove);
//         window.addEventListener(_MouseUp, fn_mouseUp);
//         window.addEventListener(_Blur, fn_mouseUp);
//         _gdo.bmd = true;
//         // console.log(e);
//         _gdo.mdx = e.offsetX;
//         _gdo.mdy = e.offsetY;
//         // console.log(_mdpt);
//         fn_mouseMove(e);
//     }
// };


// _scrwCont.addEventListener(_MouseDown, fn_mouseDown);







































// const _rctFull = _scrwCont.getBoundingClientRect();
// const _rctThumb = _scrwThumb.getBoundingClientRect();
// console.log(fn_getElementLeft(_scrwThumb));
// console.log(fn_getElementLeft(_scrwThumb));
// console.log(fn_getElementRect(_scrwThumb));



// const tgx = getComputedStyle(_scrwThumb);
// for (const tx of tgx) {
//     console.log(tx, tgx[tx]);
// }
// console.log();
// console.log(_rctFull);
// console.log(_rctThumb);




