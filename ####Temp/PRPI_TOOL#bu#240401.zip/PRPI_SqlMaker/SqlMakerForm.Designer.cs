﻿namespace PRPI_SqlMaker
{
    partial class SqlMakerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SqlMakerForm));
            this.m_grb1 = new System.Windows.Forms.GroupBox();
            this.m_cbb11 = new System.Windows.Forms.ComboBox();
            this.m_btn12 = new System.Windows.Forms.Button();
            this.m_txb11 = new System.Windows.Forms.TextBox();
            this.m_btnFunc = new System.Windows.Forms.Button();
            this.m_btn11 = new System.Windows.Forms.Button();
            this.m_grb3 = new System.Windows.Forms.GroupBox();
            this.m_btn21 = new System.Windows.Forms.Button();
            this.m_txb21 = new System.Windows.Forms.TextBox();
            this.m_grb1.SuspendLayout();
            this.m_grb3.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_grb1
            // 
            this.m_grb1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_grb1.Controls.Add(this.m_cbb11);
            this.m_grb1.Controls.Add(this.m_btn12);
            this.m_grb1.Controls.Add(this.m_txb11);
            this.m_grb1.Controls.Add(this.m_btnFunc);
            this.m_grb1.Controls.Add(this.m_btn11);
            this.m_grb1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m_grb1.Location = new System.Drawing.Point(9, 368);
            this.m_grb1.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.m_grb1.Name = "m_grb1";
            this.m_grb1.Padding = new System.Windows.Forms.Padding(0);
            this.m_grb1.Size = new System.Drawing.Size(782, 366);
            this.m_grb1.TabIndex = 5;
            this.m_grb1.TabStop = false;
            this.m_grb1.Text = "   ▩ 쿼리, 파라미터 입력   ";
            // 
            // m_cbb11
            // 
            this.m_cbb11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.m_cbb11.FormattingEnabled = true;
            this.m_cbb11.Location = new System.Drawing.Point(363, 336);
            this.m_cbb11.Name = "m_cbb11";
            this.m_cbb11.Size = new System.Drawing.Size(121, 20);
            this.m_cbb11.TabIndex = 5;
            // 
            // m_btn12
            // 
            this.m_btn12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btn12.BackColor = System.Drawing.Color.LightSteelBlue;
            this.m_btn12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btn12.Location = new System.Drawing.Point(626, 328);
            this.m_btn12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btn12.Name = "m_btn12";
            this.m_btn12.Size = new System.Drawing.Size(150, 34);
            this.m_btn12.TabIndex = 2;
            this.m_btn12.Text = "▲▲ 클립보드 넣기";
            this.m_btn12.UseVisualStyleBackColor = false;
            // 
            // m_txb11
            // 
            this.m_txb11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_txb11.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_txb11.Location = new System.Drawing.Point(3, 20);
            this.m_txb11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_txb11.Multiline = true;
            this.m_txb11.Name = "m_txb11";
            this.m_txb11.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_txb11.Size = new System.Drawing.Size(776, 300);
            this.m_txb11.TabIndex = 0;
            this.m_txb11.WordWrap = false;
            // 
            // m_btnFunc
            // 
            this.m_btnFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.m_btnFunc.BackColor = System.Drawing.Color.Plum;
            this.m_btnFunc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btnFunc.Location = new System.Drawing.Point(6, 328);
            this.m_btnFunc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btnFunc.Name = "m_btnFunc";
            this.m_btnFunc.Size = new System.Drawing.Size(130, 34);
            this.m_btnFunc.TabIndex = 4;
            this.m_btnFunc.Text = "▶▶ 기능 메뉴";
            this.m_btnFunc.UseVisualStyleBackColor = false;
            // 
            // m_btn11
            // 
            this.m_btn11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btn11.BackColor = System.Drawing.Color.LightSteelBlue;
            this.m_btn11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btn11.Location = new System.Drawing.Point(490, 328);
            this.m_btn11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btn11.Name = "m_btn11";
            this.m_btn11.Size = new System.Drawing.Size(130, 34);
            this.m_btn11.TabIndex = 3;
            this.m_btn11.Text = "▲▲ 쿼리 완성";
            this.m_btn11.UseVisualStyleBackColor = false;
            // 
            // m_grb3
            // 
            this.m_grb3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_grb3.Controls.Add(this.m_btn21);
            this.m_grb3.Controls.Add(this.m_txb21);
            this.m_grb3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m_grb3.Location = new System.Drawing.Point(9, 9);
            this.m_grb3.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.m_grb3.Name = "m_grb3";
            this.m_grb3.Size = new System.Drawing.Size(782, 350);
            this.m_grb3.TabIndex = 3;
            this.m_grb3.TabStop = false;
            this.m_grb3.Text = "   ▩ 쿼리 결과 출력   ";
            // 
            // m_btn21
            // 
            this.m_btn21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btn21.BackColor = System.Drawing.Color.LightSteelBlue;
            this.m_btn21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btn21.Location = new System.Drawing.Point(626, 309);
            this.m_btn21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btn21.Name = "m_btn21";
            this.m_btn21.Size = new System.Drawing.Size(150, 34);
            this.m_btn21.TabIndex = 1;
            this.m_btn21.Text = "▲▲ 클립보드 복사";
            this.m_btn21.UseVisualStyleBackColor = false;
            // 
            // m_txb21
            // 
            this.m_txb21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_txb21.Font = new System.Drawing.Font("나눔고딕", 8.999999F);
            this.m_txb21.Location = new System.Drawing.Point(6, 23);
            this.m_txb21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_txb21.Multiline = true;
            this.m_txb21.Name = "m_txb21";
            this.m_txb21.ReadOnly = true;
            this.m_txb21.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_txb21.Size = new System.Drawing.Size(770, 278);
            this.m_txb21.TabIndex = 0;
            this.m_txb21.WordWrap = false;
            // 
            // SqlMakerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 748);
            this.Controls.Add(this.m_grb1);
            this.Controls.Add(this.m_grb3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(100, 40);
            this.Name = "SqlMakerForm";
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.m_grb1.ResumeLayout(false);
            this.m_grb1.PerformLayout();
            this.m_grb3.ResumeLayout(false);
            this.m_grb3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox m_grb1;
        private System.Windows.Forms.TextBox m_txb11;
        private System.Windows.Forms.Button m_btnFunc;
        private System.Windows.Forms.Button m_btn11;
        private System.Windows.Forms.GroupBox m_grb3;
        private System.Windows.Forms.Button m_btn21;
        private System.Windows.Forms.TextBox m_txb21;
        private System.Windows.Forms.Button m_btn12;
        private System.Windows.Forms.ComboBox m_cbb11;
    }
}