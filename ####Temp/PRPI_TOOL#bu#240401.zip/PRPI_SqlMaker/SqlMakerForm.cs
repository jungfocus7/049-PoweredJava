﻿using PRPI_SqlMaker.DataPump;
using RootAppCommon.Controls;
using System;
using System.ComponentModel;
using System.Windows.Forms;




namespace PRPI_SqlMaker
{
    public sealed partial class SqlMakerForm : Form
    {
        #region  [ 00) 객체 초기화 영역 ]
        /// <summary>
        /// 생성자
        /// </summary>
        public SqlMakerForm()
        {
            InitializeComponent();
        }


        private const string _ftxt = "03) PRPI_SqlMaker";
        /// <summary>
        /// Load 이벤트
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            this.AlignBottomRight(40, 40);
            this.ResizeRenderingPass();
            MinimumSize = Size;
            Text = _ftxt;

            //prQueryDataLoad();
            prControlsInitialize();
        }


        /// <summary>
        /// OnClosing
        /// </summary>
        /// <param name="e"></param>
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);

            //Application.Exit();
            e.Cancel = true;
            Hide();
        }


        /// <summary>
        /// 컨트롤들 초기화
        /// </summary>
        private void prControlsInitialize()
        {
            prGroup21_InitOnce();
            prGroup11_InitOnce();

            //AllowDrop = true;
        }
        #endregion





        #region [ 02) 위에 출력 부분 ]
        /// <summary>
        /// Group02 InitOnce
        /// </summary>
        private void prGroup21_InitOnce()
        {
            m_txb21.HideSelection = false;
            m_btn21.Click += delegate
            {
                string txt = m_txb21.Text;
                if (string.IsNullOrWhiteSpace(txt)) return;

                Clipboard.SetText(txt);
            };
        }
        #endregion



        #region [ 01) 아래 입력 부분 ]
        /// <summary>
        /// Group01 InitOnce
        /// </summary>
        private void prGroup11_InitOnce()
        {
            m_txb21.HideSelection = false;

            string allText = @"
C01	C02	C03	C04	C05	C06	C07	C08	C09	C10
RA1	RA2	RA3	RA4	RA5	RA6	RA7	RA8	RA9	RA10
RB1	RB2	RB3	RB4	RB5	RB6	RB7	RB8	RB9	RB10
RC1	RC2	RC3	RC4	RC5	RC6	RC7	RC8	RC9	RC10
RD1	RD2	RD3	RD4	RD5	RD6	RD7	RD8	RD9	RD10
RE1	RE2	RE3	RE4	RE5	RE6	RE7	RE8	RE9	RE10
RF1	RF2	RF3	RF4	RF5	RF6	RF7	RF8	RF9	RF10
RG1	RG2	RG3	RG4	RG5	RG6	RG7	RG8	RG9	RG10
RH1	RH2	RH3	RH4	RH5	RH6	RH7	RH8	RH9	RH10
RI1	RI2	RI3	RI4	RI5	RI6	RI7	RI8	RI9	RI10
RJ1	RJ2	RJ3	RJ4	RJ5	RJ6	RJ7	RJ8	RJ9	RJ10
									
RK1	RK2	RK3	RK4	RK5	RK6	RK7	RK8	RK9	RK10
            ".Trim();
            m_txb11.Text = allText;


            m_btn11.Click += delegate
            {
                string txt = m_txb11.Text;
                if (string.IsNullOrWhiteSpace(txt)) return;

                using (HfSqlMaker sqlMaker = HfSqlMaker.Create(txt, "TEMP"))
                {
                    if (sqlMaker != null)
                    {
                        if (m_cbb11.SelectedItem is HfSqlType tst)
                        {
                            if (tst == HfSqlType.Select)
                                sqlMaker.MakeSelect();
                            else if (tst == HfSqlType.Update)
                                sqlMaker.MakeUpdate();
                            else if (tst == HfSqlType.Insert)
                                sqlMaker.MakeInsert();
                            else if (tst == HfSqlType.Delete)
                                sqlMaker.MakeDelete();

                            m_txb21.Text = sqlMaker.GetResult().query;
                        }
                    }
                }
            };

            m_btn12.Click += delegate
            {
                if (Clipboard.ContainsText())
                {
                    string txt = Clipboard.GetText();
                    if (string.IsNullOrWhiteSpace(txt)) return;

                    m_txb11.Text = txt;
                }
            };

            if (Enum.GetValues(typeof(HfSqlType)) is HfSqlType[] tsta)
            {
                m_cbb11.DataSource = tsta;
            }
            m_cbb11.SelectedIndexChanged += delegate
            {
                //if (m_cbb11.SelectedItem is HfSqlType tst)
                //{

                //}
            };
        }
        #endregion

    }

}
