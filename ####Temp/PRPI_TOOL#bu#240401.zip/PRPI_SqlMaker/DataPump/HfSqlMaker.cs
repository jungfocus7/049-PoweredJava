﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;




namespace PRPI_SqlMaker.DataPump
{
    public sealed class HfSqlMaker : HfQueryBuilder
    {
        #region "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 1"
        private static bool prCheckData(List<string[]> rlst)
        {
            if ((rlst == null) || (rlst.Count < 2))
                return false;

            bool rb = false;
            int ty = 0;
            foreach (string[] lsa in rlst)
            {
                int l = lsa.Length;
                if (ty == 0)
                {
                    ty = l;
                    continue;
                }

                if (ty == l)
                {
                    rb = true;
                    ty = l;
                }
                else
                {
                    rb = false;
                    break;
                }
            }

            return rb;
        }

        private static List<string[]> prLoadData(string allText)
        {
            List<string[]> rlst = null;

            string[] lsa = allText.Split(new string[] { Constants.vbNewLine }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string ls in lsa)
            {
                string[] csa = ls.Split(new string[] { Constants.vbTab }, StringSplitOptions.None);
                if (rlst == null)
                    rlst = new List<string[]>();
                rlst.Add(csa);
            }

            if (prCheckData(rlst))
                return rlst;
            else
                return null;
        }

        public static HfSqlMaker Create(string allText, string tnm)
        {
            if (string.IsNullOrWhiteSpace(allText))
                return null;

            List<string[]> rlst = prLoadData(allText);
            if (rlst == null) return null;

            HfSqlMaker dataFlower = new HfSqlMaker()
            {
                LstData = rlst,
                TableName = tnm
            };
            return dataFlower;
        }


        private HfSqlMaker() { }

        public List<string[]> LstData { get; private set; }

        public string TableName { get; private set; }

        public string[] ColNames
        {
            get
            {
                return LstData[0];
            }
        }

        public IEnumerable<string[]> Rows
        {
            get
            {
                bool bFirst = true;
                foreach (string[] rsa in LstData)
                {
                    if (bFirst)
                    {
                        bFirst = false;
                        continue;
                    }
                    yield return rsa;
                }
            }
        }


        public override void Dispose()
        {
            if (LstData == null) return;
            LstData.Clear();
            LstData = null;
            base.Dispose();
        }



        /// <summary>
        /// 값의 대입을 체크
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private static string prCheckAssign(string key, string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return $"{key} = NULL";
            else
                return $"{key} = '{value}'";
        }


        /// <summary>
        /// 값의 조건을 체크
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private static string prCheckCond(string key, string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return $"{key} IS NULL";
            else
                return $"{key} = '{value}'";
        }


        /// <summary>
        /// 값의 체크
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private static string prCheckValue(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return "NULL";
            else
                return $"'{value}'";
        }
        #endregion



        /// <summary>
        /// 컬럼을 기준으로 루프
        /// </summary>
        private void prLoopForColumns(string[] rsa, Action<string, string, int, int> cbf)
        {
            for (int l = ColNames.Length, i = 0; i < l; ++i)
            {
                string key = ColNames[i];
                string value = rsa[i];
                cbf(key, value, l, i);
            }
        }



        /// <summary>
        /// SELECT  쿼리 만들기
        /// </summary>
        public void MakeSelect()
        {
            foreach (string[] rsa in Rows)
            {
                AppendLine($"SELECT {string.Join(", ", ColNames)}");
                AppendLine($"FROM {TableName}");
                Append("WHERE");
                prLoopForColumns(rsa,
                    delegate (string key, string value, int l, int i)
                    {
                        if (i == 0)
                            AppendLine($" {prCheckCond(key, value)}");
                        else
                            AppendLine($"  AND {prCheckCond(key, value)}");
                    }
                );

                AppendLine($";{Constants.vbNewLine}");
            }
        }


        /// <summary>
        /// UPDATE  쿼리 만들기
        /// </summary>
        public void MakeUpdate()
        {
            foreach (string[] rsa in Rows)
            {
                AppendLine($"UPDATE {TableName}");
                prLoopForColumns(rsa,
                    delegate (string key, string value, int l, int i)
                    {
                        if (i == 0)
                            AppendLine($"SET {prCheckAssign(key, value)}");
                        else
                            AppendLine($"  , {prCheckAssign(key, value)}");
                    }
                );
                Append("WHERE");
                prLoopForColumns(rsa,
                    delegate (string key, string value, int l, int i)
                    {
                        if (i == 0)
                            AppendLine($" {prCheckCond(key, value)}");
                        else
                            AppendLine($"  AND {prCheckCond(key, value)}");
                    }
                );

                AppendLine($";{Constants.vbNewLine}");
            }
        }


        /// <summary>
        /// INSERT  쿼리 만들기
        /// </summary>
        public void MakeInsert()
        {
            foreach (string[] rsa in Rows)
            {
                AppendLine($"INSERT INTO {TableName}");
                AppendLine($"  ({string.Join(", ", ColNames)})");
                AppendLine("VALUES");
                IEnumerable<string> ies =
                    rsa.Select(tx => prCheckValue(tx));
                AppendLine($"  ({string.Join(", ", ies)})");

                AppendLine($";{Constants.vbNewLine}");
            }
        }


        /// <summary>
        /// DELETE  쿼리 만들기
        /// </summary>
        public void MakeDelete()
        {
            foreach (string[] rsa in Rows)
            {
                AppendLine($"DELETE FROM {TableName}");
                Append("WHERE");
                prLoopForColumns(rsa,
                    delegate (string key, string value, int l, int i)
                    {
                        if (i == 0)
                            AppendLine($" {prCheckCond(key, value)}");
                        else
                            AppendLine($"  AND {prCheckCond(key, value)}");
                    }
                );

                AppendLine($";{Constants.vbNewLine}");
            }
        }



    }


    public enum HfSqlType
    {
        Select = 1,
        Update = 2,
        Insert = 3,
        Delete = 4
    }







    /*

    public static void Main(string[] args)
    {
        string allText = @"
C01	C02	C03	C04	C05	C06	C07	C08	C09	C10
RA1	RA2	RA3	RA4	RA5	RA6	RA7	RA8	RA9	RA10
RB1	RB2	RB3	RB4	RB5	RB6	RB7	RB8	RB9	RB10
RC1	RC2	RC3	RC4	RC5	RC6	RC7	RC8	RC9	RC10
RD1	RD2	RD3	RD4	RD5	RD6	RD7	RD8	RD9	RD10
RE1	RE2	RE3	RE4	RE5	RE6	RE7	RE8	RE9	RE10
RF1	RF2	RF3	RF4	RF5	RF6	RF7	RF8	RF9	RF10
RG1	RG2	RG3	RG4	RG5	RG6	RG7	RG8	RG9	RG10
RH1	RH2	RH3	RH4	RH5	RH6	RH7	RH8	RH9	RH10
RI1	RI2	RI3	RI4	RI5	RI6	RI7	RI8	RI9	RI10
RJ1	RJ2	RJ3	RJ4	RJ5	RJ6	RJ7	RJ8	RJ9	RJ10
									
RK1	RK2	RK3	RK4	RK5	RK6	RK7	RK8	RK9	RK10
            ".Trim();



        using (HfSqlMaker sqlMaker = HfSqlMaker.Create(allText, "DATATABLE"))
        {
            if (sqlMaker != null)
            {
                sqlMaker.MakeSelect();
                sqlMaker.MakeUpdate();
                sqlMaker.MakeInsert();
                sqlMaker.MakeDelete();

                Console.WriteLine(sqlMaker.GetResult().query);
            }
        }

    }

    */

}


