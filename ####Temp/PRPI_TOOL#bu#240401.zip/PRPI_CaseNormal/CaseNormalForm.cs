﻿using Microsoft.VisualBasic;
using RootAppCommon.Controls;
using System;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;




namespace PRPI_CaseNormal
{
    public sealed partial class CaseNormalForm : Form
    {
        #region  [ 00) 객체 초기화 영역 ]
        /// <summary>
        /// 생성자
        /// </summary>
        public CaseNormalForm()
        {
            InitializeComponent();
        }


        private const string _ftxt = "02) PRPI_CaseNormal";
        /// <summary>
        /// Load 이벤트
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            this.AlignBottomRight(40, 40);
            this.ResizeRenderingPass();
            MinimumSize = Size;
            Text = _ftxt;

            //prQueryDataLoad();
            prControlsInitialize();
        }


        /// <summary>
        /// OnClosing
        /// </summary>
        /// <param name="e"></param>
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);

            //Application.Exit();
            e.Cancel = true;
            Hide();
        }


        /// <summary>
        /// 컨트롤들 초기화
        /// </summary>
        private void prControlsInitialize()
        {            
            prGroup21_InitOnce();
            prGroup11_InitOnce();

            //AllowDrop = true;
        }
        #endregion




        private static string prConvertCamelCase(string tws)
        {
            if (string.IsNullOrWhiteSpace(tws))
                return string.Empty;

            StringBuilder tsb = new StringBuilder();
            string[] jsa = tws.Split(new char[] { '_' }, StringSplitOptions.RemoveEmptyEntries);
            bool bFirst = true;
            foreach (string js in jsa)
            {
                if (bFirst)
                {
                    tsb.Append(js.ToLower());
                    bFirst = false;
                }
                else
                {
                    if (js.Length == 0)
                    {
                        tsb.Append(js.ToUpper());
                    }
                    else if (js.Length > 0)
                    {
                        tsb.Append(char.ToUpper(js[0]));
                        tsb.Append(js.Substring(1).ToLower());
                    }
                }
            }

            return tsb.ToString();
        }


        private static string prMakeString(string xps)
        {
            StringBuilder rsb = new StringBuilder();

            const string tsp = Constants.vbTab; //"	"
            string[] lsa = xps.Split(new string[] { tsp }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string ls in lsa)
            {
                string tw = prConvertCamelCase(ls);
                rsb.AppendLine($"private String {tw};");
            }


            string rtxt = rsb.ToString();
            return rtxt;
        }





        #region [ 02) 위에 출력 부분 ]
        //private CmsEx m_cms11;
        //private Tsmi41Group m_tsmi41;
        //private CmsEx m_cmsFunc;


        /// <summary>
        /// Group01 InitOnce
        /// </summary>
        private void prGroup21_InitOnce()
        {
            m_txb21.HideSelection = false;
            m_btn21.Click += delegate
            {
                string txt = m_txb21.Text;
                if (string.IsNullOrWhiteSpace(txt)) return;

                Clipboard.SetText(txt);
            };
        }
        #endregion




        #region [ 01) 아래 입력 부분 ]
        private string _ipxs = "SPECI_CREAT_NO	SPECI_CREAT_SN	RCPER_INSTT_SYMB	MDEX_ST_DT	INSUR_CLAIM_DAYS	REVW_MDEX_RSLT_CD	STD_DIAG_CD1	STD_DIAG_CD2	STD_DIAG_CD3	STD_DIAG_CD4	STD_DIAG_CD5	STD_DIAG_CD6	STD_DIAG_CD7	STD_DIAG_CD8	STD_DIAG_CD9	STD_DIAG_CD10	PRCD_SVCFEE_CD1	PRCD_SVCFEE_CD2	PRCD_SVCFEE_CD3	PRCD_SVCFEE_CD4	PRCD_SVCFEE_CD5	PRCD_SVCFEE_CD6	PRCD_SVCFEE_CD7	PRCD_SVCFEE_CD8	PRCD_SVCFEE_CD9	PRCD_SVCFEE_CD10	EXAM_SVCFEE_CD1	EXAM_SVCFEE_CD2	EXAM_SVCFEE_CD3	EXAM_SVCFEE_CD4	EXAM_SVCFEE_CD5	RAD_SVCFEE_CD1	RAD_SVCFEE_CD2	RAD_SVCFEE_CD3	RAD_SVCFEE_CD4	RAD_SVCFEE_CD5	INJT_BLDV_SVCFEE_CD1	INJT_BLDV_SVCFEE_CD2	INJT_BLDV_SVCFEE_CD3	INJT_BLDV_SVCFEE_CD4	INJT_BLDV_SVCFEE_CD5	ANST_RSPT_TRET_SVCFEE_CD1	ANST_RSPT_TRET_SVCFEE_CD2	ANST_RSPT_TRET_SVCFEE_CD3	ANST_RSPT_TRET_SVCFEE_CD4	ANST_RSPT_TRET_SVCFEE_CD5	ALCH_DRAD_RHBL_TRET_CD	DRG_ADD_CD1	DRG_ADD_CD2	DRG_ADD_CD3	DRG_ADD_CD4	DRG_ADD_CD5	ADMIS_W_WGHT_VAL	ARTL_RSPT_TMC	DRG_MAINDIAG_CAT_CD	ADRG_CD	SVRT_DECSN_STEP_DIV_CD	KDRG_CD	VRSN_NO	DRG_SPECI_RMRK	FRST_ENTR_EMPNO	FRST_ENTR_DTM	FINL_UPID_EMPNO	FINL_UPDT_DTM";


        /// <summary>
        /// Group01 InitOnce
        /// </summary>
        private void prGroup11_InitOnce()
        {
            m_txb11.HideSelection = false;
            m_txb11.Text = _ipxs;

            m_btn11.Click += delegate
            {
                string txt = m_txb11.Text;
                if (string.IsNullOrWhiteSpace(txt)) return;

                string rtxt = prMakeString(txt);
                m_txb21.Text = rtxt;
            };

            m_btn12.Click += delegate
            {
                if (Clipboard.ContainsText())
                {
                    string txt = Clipboard.GetText();
                    if (string.IsNullOrWhiteSpace(txt)) return;

                    m_txb11.Text = txt;
                }
            };
        }
        #endregion



    }

}
