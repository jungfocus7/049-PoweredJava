﻿namespace PRPI_CaseNormal
{
    partial class CaseNormalForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CaseNormalForm));
            this.m_grb1 = new System.Windows.Forms.GroupBox();
            this.m_btnFunc = new System.Windows.Forms.Button();
            this.m_btn11 = new System.Windows.Forms.Button();
            this.m_txb11 = new System.Windows.Forms.TextBox();
            this.m_grb2 = new System.Windows.Forms.GroupBox();
            this.m_btn21 = new System.Windows.Forms.Button();
            this.m_txb21 = new System.Windows.Forms.TextBox();
            this.m_btn12 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.m_grb1.SuspendLayout();
            this.m_grb2.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_grb1
            // 
            this.m_grb1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_grb1.Controls.Add(this.m_btn12);
            this.m_grb1.Controls.Add(this.m_btnFunc);
            this.m_grb1.Controls.Add(this.m_btn11);
            this.m_grb1.Controls.Add(this.m_txb11);
            this.m_grb1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.m_grb1.Location = new System.Drawing.Point(9, 332);
            this.m_grb1.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.m_grb1.Name = "m_grb1";
            this.m_grb1.Padding = new System.Windows.Forms.Padding(0);
            this.m_grb1.Size = new System.Drawing.Size(646, 327);
            this.m_grb1.TabIndex = 5;
            this.m_grb1.TabStop = false;
            this.m_grb1.Text = "   ▩ 입력 문자열";
            // 
            // m_btnFunc
            // 
            this.m_btnFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btnFunc.BackColor = System.Drawing.Color.Plum;
            this.m_btnFunc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btnFunc.Location = new System.Drawing.Point(198, 289);
            this.m_btnFunc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btnFunc.Name = "m_btnFunc";
            this.m_btnFunc.Size = new System.Drawing.Size(130, 34);
            this.m_btnFunc.TabIndex = 4;
            this.m_btnFunc.Text = "▶▶ 기능 메뉴";
            this.m_btnFunc.UseVisualStyleBackColor = false;
            // 
            // m_btn11
            // 
            this.m_btn11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btn11.BackColor = System.Drawing.Color.LightSteelBlue;
            this.m_btn11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btn11.Location = new System.Drawing.Point(334, 289);
            this.m_btn11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btn11.Name = "m_btn11";
            this.m_btn11.Size = new System.Drawing.Size(150, 34);
            this.m_btn11.TabIndex = 3;
            this.m_btn11.Text = "▲▲ 문자열 만들기";
            this.m_btn11.UseVisualStyleBackColor = false;
            // 
            // m_txb11
            // 
            this.m_txb11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_txb11.Font = new System.Drawing.Font("나눔고딕", 8.999999F);
            this.m_txb11.Location = new System.Drawing.Point(3, 18);
            this.m_txb11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_txb11.Multiline = true;
            this.m_txb11.Name = "m_txb11";
            this.m_txb11.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_txb11.Size = new System.Drawing.Size(640, 263);
            this.m_txb11.TabIndex = 1;
            this.m_txb11.WordWrap = false;
            // 
            // m_grb2
            // 
            this.m_grb2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_grb2.Controls.Add(this.m_btn21);
            this.m_grb2.Controls.Add(this.m_txb21);
            this.m_grb2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold);
            this.m_grb2.Location = new System.Drawing.Point(9, 9);
            this.m_grb2.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.m_grb2.Name = "m_grb2";
            this.m_grb2.Size = new System.Drawing.Size(646, 314);
            this.m_grb2.TabIndex = 4;
            this.m_grb2.TabStop = false;
            this.m_grb2.Text = "   ▩ Java 객체로 맴버로 출력   ";
            // 
            // m_btn21
            // 
            this.m_btn21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btn21.BackColor = System.Drawing.Color.LightSteelBlue;
            this.m_btn21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btn21.Location = new System.Drawing.Point(490, 272);
            this.m_btn21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btn21.Name = "m_btn21";
            this.m_btn21.Size = new System.Drawing.Size(150, 34);
            this.m_btn21.TabIndex = 1;
            this.m_btn21.Text = "▲▲ 클립보드 복사";
            this.m_btn21.UseVisualStyleBackColor = false;
            // 
            // m_txb21
            // 
            this.m_txb21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_txb21.Font = new System.Drawing.Font("나눔고딕", 8.999999F);
            this.m_txb21.Location = new System.Drawing.Point(6, 23);
            this.m_txb21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_txb21.Multiline = true;
            this.m_txb21.Name = "m_txb21";
            this.m_txb21.ReadOnly = true;
            this.m_txb21.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_txb21.Size = new System.Drawing.Size(634, 238);
            this.m_txb21.TabIndex = 0;
            this.m_txb21.WordWrap = false;
            // 
            // m_btn12
            // 
            this.m_btn12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btn12.BackColor = System.Drawing.Color.LightSteelBlue;
            this.m_btn12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.m_btn12.Location = new System.Drawing.Point(490, 289);
            this.m_btn12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.m_btn12.Name = "m_btn12";
            this.m_btn12.Size = new System.Drawing.Size(150, 34);
            this.m_btn12.TabIndex = 5;
            this.m_btn12.Text = "▲▲ 클립보드 넣기";
            this.m_btn12.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Location = new System.Drawing.Point(490, 289);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 34);
            this.button1.TabIndex = 5;
            this.button1.Text = "▲▲ 클립보드 넣기";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // CaseNormalForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 673);
            this.Controls.Add(this.m_grb1);
            this.Controls.Add(this.m_grb2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(100, 40);
            this.Name = "CaseNormalForm";
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.m_grb1.ResumeLayout(false);
            this.m_grb1.PerformLayout();
            this.m_grb2.ResumeLayout(false);
            this.m_grb2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox m_grb1;
        private System.Windows.Forms.Button m_btnFunc;
        private System.Windows.Forms.Button m_btn11;
        private System.Windows.Forms.TextBox m_txb11;
        private System.Windows.Forms.GroupBox m_grb2;
        private System.Windows.Forms.Button m_btn21;
        private System.Windows.Forms.TextBox m_txb21;
        private System.Windows.Forms.Button m_btn12;
        private System.Windows.Forms.Button button1;
    }
}