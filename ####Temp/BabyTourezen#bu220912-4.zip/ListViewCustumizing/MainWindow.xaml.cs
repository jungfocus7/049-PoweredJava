﻿using ListViewCustumizing.CustomTemplate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;




namespace ListViewCustumizing
{
    public sealed partial class MainWindow : Window
    {
        private static string ppPrintXaml(object to)
        {
            try
            {
                string strXaml = XamlWriter.Save(to);
                XDocument txd = XDocument.Parse(strXaml);
                string tstr = txd.ToString();
                tstr = tstr.Replace(" xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"", string.Empty);
                tstr = tstr.Replace(" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\"", string.Empty);
                tstr = tstr.Replace(" xmlns:lvcct=\"clr-namespace:ListViewCustumizing.CustomTemplate;assembly=ListViewCustumizing\"", string.Empty);
                //Clipboard.SetText(tstr);
                return tstr;
            }
            catch { }
            return null;
        }

        private static int _xc = 0;
        private static StringBuilder _sb = new StringBuilder();
        private static void ppFindChildLoop<T>(
            DependencyObject tcdo, Action<T, int> tcb) where T : FrameworkElement
        {
            int tl = VisualTreeHelper.GetChildrenCount(tcdo);
            for (int i = 0; i < tl; i++)
            {
                DependencyObject tdo = VisualTreeHelper.GetChild(tcdo, i);
                if (tdo is T to)
                    tcb(to, _xc++);
                ppFindChildLoop(tdo, tcb);
            }
        }





        public MainWindow()
        {
            InitializeComponent();
            Loaded += ppLoaded;
        }

        private void ppLoaded(object tsd, RoutedEventArgs tea)
        {
            Loaded -= ppLoaded;

            _grdrt.Width = double.NaN;
            _grdrt.Height = double.NaN;
            SizeToContent = SizeToContent.Manual;


            DataItems = new TxDataItemCollection()
            {
                new TxDataItem() { Num = 1, Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Num = 2, Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Num = 3, Name = "임헌진", Age = "36", Job = "건설업" }
            };
            int tn = 4;
            for (int i = 0; i < 100000; i++)
            {
                DataItems.Add(new TxDataItem() { Num = tn++, Name = "정희범", Age = "36", Job = "프로그래머" });
                DataItems.Add(new TxDataItem() { Num = tn++, Name = "박종명", Age = "36", Job = "유통업" });
                DataItems.Add(new TxDataItem() { Num = tn++, Name = "임헌진", Age = "36", Job = "건설업" });
            }
            _lstvOne.ItemsSource = DataItems;


            ppControlsEventer();
        }

        public TxDataItemCollection DataItems { get; private set; }




        private void ppControlsEventer()
        {
            _btn31.Click += delegate
            {
                //ppPrintXaml(_lstvOne);

                _xc = 0;
                _sb.Clear();
                ppFindChildLoop(_lstvOne,
                    delegate (Control tco, int ti)
                    {
                        _sb.AppendLine(
                            string.Format("#{{{{ (Num={0}, Target={1}, Parent={2})",
                                ti + 1, tco.ToString(), tco.Parent));
                        _sb.AppendLine(ppPrintXaml(tco.Template));
                        _sb.AppendLine("}}\n\n\n");
                    });
                Clipboard.SetText(_sb.ToString());
                _sb.Clear();
            };
        }




    }
}
