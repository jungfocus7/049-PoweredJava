﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;




namespace ListViewCustumizing.CustomTemplate
{
    public sealed partial class TxListViewItem : ListViewItem
    {
        public TxListViewItem()
        {
            InitializeComponent();
            Loaded += ppLoaded;
        }

        private void ppLoaded(object tsd, RoutedEventArgs tea)
        {
            Loaded -= ppLoaded;

            //_data = (TxDataItem)Content;
            //_pnl = (Panel)VisualTreeHelper.GetParent(this);
            //_bdrt = TxHelper.FindChild<Border>(this, "_bdrt");
            //_cbb = TxHelper.FindChild<CheckBox>(this, "_ccb");

            TxDataItem tdi = ppGetData();
            if (tdi != null)
            {
                Binding tbd = new Binding("Checked");
                tbd.Source = tdi;
                SetBinding(IsSelectedProperty, tbd);
            }
        }

        private TxDataItem _data;
        private TxDataItem ppGetData()
        {
            if (_data == null)
                _data = (TxDataItem)Content;
            return _data;
        }
        private void ppSetDataChecked(bool tb)
        {
            TxDataItem tdi = ppGetData();
            if (tdi != null)
                tdi.Checked = tb;
        }

        private TxDataItemCollection _dataItems;
        private TxDataItemCollection ppGetDataItems()
        {
            if (_dataItems == null)
            {
                TxHelper.FindParent(this, "_lstvOne",
                    delegate (ListView tlv, int ti)
                    {
                        _dataItems = tlv.ItemsSource as TxDataItemCollection;
                    });
            }
            return _dataItems;
        }
        private int ppGetDataIndex(TxDataItem tdi)
        {
            TxDataItemCollection tdic = ppGetDataItems();
            if (tdic != null)
            {
                int trv = -1;
                int tl = tdic.Count;
                for (int i = 0; i < tl; i++)
                {
                    if (tdic[i] == tdi)
                    {
                        trv = i;
                        break;
                    }
                }
                return trv;
            }

            return -1;
        }
        private void ppSetDataCheckeds(int ts, int te, bool tb)
        {
            TxDataItemCollection tdic = ppGetDataItems();
            if (tdic != null)
            {
                int tl = tdic.Count;
                for (int i = 0; i < tl; i++)
                {
                    if ((i >= ts) && (i <= te))
                    {
                        TxDataItem tdi = tdic[i];
                        tdi.Checked = tb;
                    }
                }
            }
        }


        private Panel _pnl;
        private Panel ppGetPanel()
        {
            if (_pnl == null)
                _pnl = (Panel)VisualTreeHelper.GetParent(this);
            return _pnl;
        }

        private Border _bdrt;
        private void ppSetBorderBrush(Brush tbrs)
        {
            if (_bdrt == null)
                _bdrt = TxHelper.FindChild<Border>(this, "_bdrt");
            if (_bdrt != null)
                _bdrt.BorderBrush = tbrs;
        }
        private void ppSetBorderBackground(Brush tbrs)
        {
            if (_bdrt == null)
                _bdrt = TxHelper.FindChild<Border>(this, "_bdrt");
            if (_bdrt != null)
                _bdrt.Background = tbrs;
        }

        private CheckBox _cbb;
        private void ppSetCheckBox(bool tb)
        {
            if (_cbb == null)
                _cbb = TxHelper.FindChild<CheckBox>(this, "_ccb");
            if (_cbb != null)
                _cbb.IsChecked = tb;
        }

        private static int _prvc;

        private void ppCheckApply(bool tb)
        {
            TxDataItem tdi = ppGetData();
            if (tdi == null) return;


            int ti = ppGetDataIndex(tdi);

            if (Keyboard.Modifiers == ModifierKeys.Shift)
            {
                if (_prvc > -1)
                {
                    ppSetDataCheckeds(Math.Min(_prvc, ti), Math.Max(_prvc, ti), tb);
                }
            }

            _prvc = ti;
        }


        protected override void OnUnselected(RoutedEventArgs tea)
        {
            base.OnUnselected(tea);

            ppSetDataChecked(false);
            ppSetBorderBrush(Brushes.Transparent);
            ppSetCheckBox(false);
        }

        protected override void OnSelected(RoutedEventArgs tea)
        {
            base.OnSelected(tea);

            ppSetDataChecked(true);
            ppSetBorderBrush(Brushes.DarkOrange);
            ppSetCheckBox(true);

            //Keyboard.Focus(this);
            //FocusManager.SetFocusedElement(_pnl, this);
            //Focus();
        }


        protected override void OnMouseLeave(MouseEventArgs tea)
        {
            base.OnMouseLeave(tea);

            ppSetBorderBackground(Brushes.Transparent);
        }

        protected override void OnMouseEnter(MouseEventArgs tea)
        {
            base.OnMouseEnter(tea);

            ppSetBorderBackground(Brushes.PeachPuff);
        }



        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs tea)
        {
            base.OnMouseLeftButtonDown(tea);

            ppCheckApply(IsSelected);
        }

    }
}
