﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;




namespace ListViewCustumizing.CustomTemplate
{
    public sealed partial class TxListView : ListView
    {
        public TxListView()
        {
            InitializeComponent();

            Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, 10d);
            Resources.Add(SystemParameters.VerticalScrollBarWidthKey, 10d);

            Loaded += ppLoaded;
        }

        private void ppLoaded(object tsd, RoutedEventArgs tea)
        {
            Loaded -= ppLoaded;
        }

        protected override DependencyObject GetContainerForItemOverride()
        {
            return new TxListViewItem();
        }
    }
}
