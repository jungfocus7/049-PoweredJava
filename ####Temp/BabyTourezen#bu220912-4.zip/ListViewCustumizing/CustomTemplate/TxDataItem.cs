﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace ListViewCustumizing.CustomTemplate
{
    public sealed class TxDataItem : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string tpnm)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(tpnm));
        }

        public int Num { get; set; }
        public string NumStr
        {
            get { return Num.ToString().PadLeft(6, '0'); }
        }

        private bool _checked = false;
        public bool Checked
        {
            get { return _checked; }
            set
            {
                if (_checked == value) return;
                _checked = value;
                OnPropertyChanged("Checked");
            }
        }

        public string Name { get; set; }
        
        public string Age { get; set; }

        public string Job { get; set; }
    }


    public sealed class TxDataItemCollection : ObservableCollection<TxDataItem> { }

}
