﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;




namespace ListViewCustumizing.CustomTemplate
{
    public static class TxHelper
    {
        private static int _cnt = 0;

        private static void ppFindChild<T>(DependencyObject tcdo, string tnm, Action<T, int> tcb)
            where T : FrameworkElement
        {
            int tl = VisualTreeHelper.GetChildrenCount(tcdo);
            for (int i = 0; i < tl; i++)
            {
                DependencyObject tdo = VisualTreeHelper.GetChild(tcdo, i);
                if (tdo is FrameworkElement tfe)
                {
                    if ((tfe is T tt) && (tt.Name == tnm))
                    {
                        tcb(tt, _cnt);
                        break;
                    }
                }
                ++_cnt;

                ppFindChild(tdo, tnm, tcb);
            }
        }


        private static DependencyObject _rdo;
        public static T FindChild<T>(DependencyObject tcdo, string tnm)
            where T : FrameworkElement
        {
            _cnt = 0;
            _rdo = null;
            ppFindChild(tcdo, tnm,
                delegate (T tco, int ti)
                {
                    _rdo = tco;
                });

            T trv = (T)_rdo;
            _cnt = 0;
            _rdo = null;

            return trv;
        }



        public static void FindParent<T>(DependencyObject tdo, string tnm, Action<T, int> tcb)
            where T : FrameworkElement
        {
            _cnt = 0;

            DependencyObject tcdo = VisualTreeHelper.GetParent(tdo);
            do
            {
                if (tcdo is FrameworkElement tfe)
                {
                    if ((tfe is T tt) && (tt.Name == tnm))
                    {
                        tcb(tt, _cnt);
                        break;
                    }
                }
                ++_cnt;

                tcdo = VisualTreeHelper.GetParent(tcdo);                
            } 
            while (tcdo != null);
        }

    }
}
