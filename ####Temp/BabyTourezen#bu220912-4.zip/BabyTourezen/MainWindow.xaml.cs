﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Markup;
using System.Diagnostics;
using System.Xml.Linq;
using System.Windows.Threading;
using Microsoft.Windows.Themes;
using System.Windows.Controls.Primitives;
using System.Collections.ObjectModel;
using System.ComponentModel;
using BabyTourezen.CustomControls;

namespace BabyTourezen
{
    public sealed partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += ppLoaded;
        }

        private void ppLoaded(object tsd, RoutedEventArgs tea)
        {
            SizeToContent = SizeToContent.Manual;
            _grdrt.Width = double.NaN;
            _grdrt.Height = double.NaN;

            //SystemFonts.StatusFontFamilyKey;
            //SystemColors.ActiveBorderBrush;
            //SystemParameters.Border;
            //SystemParameters.HorizontalScrollBarHeightKey;
            //SystemParameters.VerticalScrollBarWidthKey;


            TxDataItemCollection tdic = new TxDataItemCollection()
            {
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
                new TxDataItem() { Name = "정희범", Age = "36", Job = "프로그래머" },
                new TxDataItem() { Name = "박종명", Age = "36", Job = "유통업" },
                new TxDataItem() { Name = "임헌진", Age = "36", Job = "건설업" },
            };
            _lstvOne.ItemsSource = tdic;
            _lstvOne.SelectionChanged += delegate
            {
            };


            _btn33.Click += delegate
            {
                //Clipboard.SetText(_txbOne.Text);
            };

            _btn32.Click += delegate
            {
                //ppTrace(null);
            };

            _btn31.Click += delegate
            {
                //ppPrintXaml(_lstvOne.Template);

                //_xc = 0;
                //ppFindChildLoop(_lstvOne,
                //    delegate (Control tco, int ti)
                //    {
                //        Action func = delegate
                //        {
                //            Dispatcher.BeginInvoke(DispatcherPriority.Normal,
                //                (Action)delegate
                //                {
                //                    ppTrace(string.Format("#{{{{ {0}: {1}",
                //                        ti + 1, tco.ToString()));
                //                    ppPrintXaml(tco.Template);
                //                    ppTrace("}}\n\n\n");
                //                });
                //        };
                //        func.BeginInvoke(null, null);
                //    });





                ppFindChildLoop(_lstvOne,
                    delegate (GridViewRowPresenter tgvrp, int ti)
                    {

                        //int tl = tgvrp.Columns.Count;
                        //if (tl > 3)
                        //    tgvrp.Columns.RemoveAt(tl - 1);
                    });

            };
        }







        private void ppTrace(string tmsg)
        {
            if (tmsg == null)
                _txbOne.Clear();
            else
                _txbOne.AppendText(tmsg + Environment.NewLine);
        }

        private void ppPrintXaml(object to)
        {
            try
            {
                string strXaml = XamlWriter.Save(to);
                XDocument txd = XDocument.Parse(strXaml);
                string tstr = txd.ToString();
                tstr = tstr.Replace(" xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"", string.Empty);
                tstr = tstr.Replace(" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\"", string.Empty);
                ppTrace(tstr);
            }
            catch { }
        }

        private void ppPrintChilds(Visual tv)
        {
            try
            {
                int tl = VisualTreeHelper.GetChildrenCount(tv);
                for (int i = 0; i < tl; i++)
                {
                    DependencyObject tdo = VisualTreeHelper.GetChild(tv, i);
                    string tu = string.Format("{0}, {1}", i, tdo.GetType().Name);
                    ppTrace(tu);
                }
            }
            catch { }
        }

        private int _xc = 0;
        private void ppFindChildLoop<T>(
            DependencyObject tcdo, Action<T, int> tcb) where T : FrameworkElement
        {
            int tl = VisualTreeHelper.GetChildrenCount(tcdo);
            for (int i = 0; i < tl; i++)
            {
                DependencyObject tdo = VisualTreeHelper.GetChild(tcdo, i);
                //ppTrace(tdo.ToString());
                if (tdo is T to) tcb(to, _xc++);
                ppFindChildLoop(tdo, tcb);
            }
        }



    }






    public sealed class TxDataItem/* : INotifyPropertyChanged*/
    {/*
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string tpnm)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(tpnm));
        }*/

        public bool Checked { get; set; } = false;
        public string Name { get; set; }
        public string Age { get; set; }
        public string Job { get; set; }
    }

    public sealed class TxDataItemCollection : ObservableCollection<TxDataItem> { }





}
