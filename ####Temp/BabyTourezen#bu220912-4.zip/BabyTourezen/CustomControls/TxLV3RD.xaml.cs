﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;

namespace BabyTourezen.CustomControls
{
    public sealed partial class TxLV3RD : ResourceDictionary
    {
        private TxLV3RD()
        {
            InitializeComponent();
        }
        public static readonly TxLV3RD Rdic = new TxLV3RD();

        private void GridViewRowPresenter_Loaded(object sender, RoutedEventArgs e)
        {
            //if (sender is GridViewRowPresenter tgvrp)
            //{
            //    var tx0 = VisualTreeHelper.GetChild(tgvrp, 0);
            //    var tx1 = VisualTreeHelper.GetChild(tgvrp, 1);
            //    var tx2 = VisualTreeHelper.GetChild(tgvrp, 2);
            //    var tx3 = VisualTreeHelper.GetChild(tgvrp, 3);
            //    var tx4 = VisualTreeHelper.GetChild(tgvrp, 4);
            //    var tx5 = VisualTreeHelper.GetChild(tgvrp, 5);
            //    var tx6 = VisualTreeHelper.GetChild(tx0, 0);
            //    var tx11 = tgvrp.FindName("_ccb");
            //    var tx12 = tgvrp.Columns[0].CellTemplate;
            //    //var tx13 = tx12.FindName("_ccb", tx12.);
            //    //tgvrp.Columns[0].CellTemplate = null;

            //    if (tx0 is ContentPresenter tcp)
            //    {
            //        //var tf1 = tcp.Co;
            //        DataTemplate tdt = tcp.ContentTemplate;
            //        var tf3 = XamlWriter.Save(tdt);


            //        //var tf1 = tdt.FindName("_ccb", tcp);


            //        //DispatcherTimer timer = new DispatcherTimer();
            //        //timer.Tick += delegate
            //        //{
            //        //    tcp.ContentTemplate = null;
            //        //};
            //        //timer.Interval = TimeSpan.FromSeconds(3);
            //        //timer.Start();
            //    }
            //}
        }

        private void PART_HeaderGripper_Initialized(object sender, EventArgs e)
        {
            if (sender is FrameworkElement tfe)
            {
                tfe.Cursor = Cursors.SizeWE;
            }
        }

        private void PART_HeaderGripper_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement tfe)
            {
                tfe.Cursor = Cursors.SizeWE;
            }

        }
    }


    public sealed partial class TxGVCH3 : GridViewColumnHeader
    {
        private static ControlTemplate _ct;
        static TxGVCH3()
        {
            if (TxLV3RD.Rdic["_gvcht"] is ControlTemplate tct)
                _ct = tct;
        }

        public TxGVCH3()
        {
            OverridesDefaultStyle = true;
            Template = _ct;
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

        }
    }


    public sealed class TxLVI3 : ListViewItem
    {
        private static ControlTemplate _ct;
        static TxLVI3()
        {            
            if (TxLV3RD.Rdic["_lvist"] is ControlTemplate tct)
                _ct = tct;
        }

        internal TxLVI3()
        {
            OverridesDefaultStyle = true;
            //FocusVisualStyle = null;
            Template = _ct;
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            _bdrt = _ct.FindName("_bdrt", this) as Border;
            _gvrp = _ct.FindName("_gvrp", this) as GridViewRowPresenter;
            _ccb = null;
        }

        private Border _bdrt;
        private GridViewRowPresenter _gvrp;
        private CheckBox _ccb;

        private void ppSetCheckBox(bool tb)
        {
            if (_ccb == null)
            {
                TxHelper.FindChild(this, "_ccb",
                    delegate (CheckBox tcb, int tc)
                    {
                        _ccb = tcb;
                    });
            }
            if (_ccb != null)
                _ccb.IsChecked = tb;
        }


        protected override void OnMouseLeave(MouseEventArgs tea)
        {
            base.OnMouseLeave(tea);            
            _bdrt.Background = Brushes.Transparent;
            if (IsSelected) return;
            _bdrt.BorderBrush = Brushes.Transparent;
        }

        protected override void OnMouseEnter(MouseEventArgs tea)
        {
            base.OnMouseEnter(tea);
            _bdrt.Background = Brushes.PeachPuff;
            if (IsSelected) return;            
            _bdrt.BorderBrush = Brushes.DarkOrange;
        }


        protected override void OnUnselected(RoutedEventArgs tea)
        {
            base.OnUnselected(tea);
            _bdrt.Background = Brushes.Transparent;
            _bdrt.BorderBrush = Brushes.Transparent;
            ppSetCheckBox(false);            
        }

        protected override void OnSelected(RoutedEventArgs tea)
        {
            base.OnSelected(tea);
            _bdrt.Background = Brushes.PeachPuff;
            _bdrt.BorderBrush = Brushes.DarkBlue;
            ppSetCheckBox(true);
            
            //_gvrp.Focus();
            //Keyboard.Focus(this);
            //FocusManager.SetFocusedElement(VisualTreeHelper.GetParent(this), this);
            
        }

    }


    public sealed class TxLV3 : ListView
    {
        public TxLV3()
        {
            Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, 10d);
            Resources.Add(SystemParameters.VerticalScrollBarWidthKey, 10d);            
            if (TxLV3RD.Rdic["_lstvt"] is ControlTemplate tct)
            {
                OverridesDefaultStyle = true;
                Template = tct;
            }
        }

        protected override DependencyObject GetContainerForItemOverride()
        {
            return new TxLVI3();
        }
    }




    public static class TxHelper
    {
        private static void ppFindChild<T>(DependencyObject tcdo, string tnm, Action<T, int> tcb)
            where T : FrameworkElement
        {
            int tl = VisualTreeHelper.GetChildrenCount(tcdo);
            for (int i = 0; i < tl; i++)
            {
                DependencyObject tdo = VisualTreeHelper.GetChild(tcdo, i);
                if (tdo is FrameworkElement tfe)
                {
                    if ((tfe is T tt) && (tt.Name == tnm))
                    {
                        tcb(tt, _cnt);
                        break;
                    }
                }
                ++_cnt;

                ppFindChild(tdo, tnm, tcb);
            }
        }

        private static int _cnt = 0;


        public static void FindChild<T>(DependencyObject tcdo, string tnm, Action<T, int> tcb)
            where T : FrameworkElement
        {
            _cnt = 0;
            ppFindChild(tcdo, tnm, tcb);
        }
    }


}
