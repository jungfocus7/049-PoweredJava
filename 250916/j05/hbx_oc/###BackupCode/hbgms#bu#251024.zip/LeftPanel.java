package hbgms;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;


public final class LeftPanel extends JPanel {
    /**
     * ColorPanelLeft
     */
    private static final Color _clpl = new Color(0x997755);

    /**
     * LeftPanel 생성자
     */
    public LeftPanel() {
        setBackground(_clpl);
        setPreferredSize(new Dimension(150, 0));
    }

    @Override
    protected void paintComponent(Graphics tg) {
        if (MainApp.checkNotRenderable()) {
            return;
        }

        // MainApp.println("###LeftPanel##paintComponent");
        super.paintComponent(tg);

        tg.setColor(Color.red);
        tg.fillRect(10, 10, 50, 50);
    }

}
