package hbgms.logics;

import hbgms.hbgms.models.IndexRanger;

public final class GameConfig {
    private static final int _celw = 27;
    /**
     * CellWidth
     * @param an
     * @return
     */
    public static int get_celw(int an) {
        return _celw + an;
    }

    private static final int _celh = 27;
    /**
     * CellHeight
     * @param an
     * @return
     */
    public static int get_celh(int an) {
        return _celh + an;
    }

    private static final int _colc = 10;
    /**
     * ColumnCount
     * @param an
     * @return
     */
    public static int get_colc(int an) {
        return _colc + an;
    }

    private static final int _rowc = 20;
    /**
     * RowCount
     * @param an
     * @return
     */
    public static int get_rowc(int an) {
        return _rowc + an;
    }

    private static final int _grdw = get_celw(1) * _colc;
    /**
     * GroundWidth
     * @param an
     * @return
     */
    public static int get_grdw(int an) {
        return _grdw + an;
    }

    private static final int _grdh = get_celh(1) * _rowc;
    /**
     * GroundHeight
     * @param an
     * @return
     */
    public static int get_grdh(int an) {
        return _grdh + an;
    }

    /**
     * CreateIndexRanger
     * @param spm
     * @return
     */
    public static IndexRanger create_idr(ShapeMap spm) {
        return new IndexRanger(
            0, get_colc(1 - spm.get_colc(0)),
            0, get_rowc(1 - spm.get_rowc(0)));
    }

}
